# Current formal Baseline engine

`fixed12_runner.py` owns the 12 reusable anonymous-query Baselines. InterProScan is run independently through `tools/run_baselines.py run-interproscan`. The current package contains only the approved formal set; diagnostic and abandoned adapters are absent.
