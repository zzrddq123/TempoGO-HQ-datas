#!/usr/bin/env python3
"""Build the Z-69 LAFA-derived temporal benchmark without network access.

The candidate universe is the published LAFA Sep-2025 -> Mar-2026 target list.
The public prediction universe is fixed before current annotations are examined:
all candidates whose reviewed UniProt sequence is byte-identical at T0 and T1.
Only the evaluator-private scoring mask depends on newly acquired T1 labels.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import shutil
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any, Iterable, TextIO

SCHEMA = "pi-lafa-temporal-benchmark.v1"
GOLD_SCHEMA = "pi-lafa-temporal-private-gold.v1"
ROOTS = {"F": "GO:0003674", "P": "GO:0008150", "C": "GO:0005575"}
NAMESPACES = {
    "molecular_function": "F",
    "biological_process": "P",
    "cellular_component": "C",
}
ASPECT_NAMES = {value: key for key, value in NAMESPACES.items()}
ELIGIBLE_EVIDENCE = {
    "EXP", "IDA", "IPI", "IMP", "IGI", "IEP",
    "HTP", "HDA", "HMP", "HGI", "HEP", "IC", "TAS",
}
EXPERIMENTAL_EVIDENCE = ELIGIBLE_EVIDENCE - {"IC", "TAS"}
ACCESSION = re.compile(r"^[A-Z0-9]+$")
GO_ID = re.compile(r"^GO:\d{7}$")


class BuildError(RuntimeError):
    pass


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, allow_nan=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def with_hash(value: dict[str, Any]) -> dict[str, Any]:
    output = dict(value)
    output["canonicalHash"] = hashlib.sha256(canonical_bytes(output)).hexdigest()
    return output


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def source_record(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise BuildError(f"{label} must be an ordinary file: {path}")
    return {
        "label": label,
        "fileName": path.name,
        "sizeBytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def write_json(path: Path, value: Any, private: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700 if private else 0o755)
    path.write_bytes(json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
    if private:
        path.chmod(0o600)


def text_open(path: Path) -> TextIO:
    if path.suffix == ".gz":
        return gzip.open(path, "rt", encoding="utf-8")
    return path.open("rt", encoding="utf-8")


def load_targets(path: Path) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    for raw in path.read_text(encoding="utf-8").splitlines():
        accession = raw.strip().split("\t", 1)[0].upper()
        if not accession or accession.lower() in {"entryid", "accession"}:
            continue
        if not ACCESSION.fullmatch(accession):
            raise BuildError(f"invalid target accession: {accession}")
        if accession in seen:
            raise BuildError(f"duplicate target accession: {accession}")
        seen.add(accession)
        values.append(accession)
    if not values:
        raise BuildError("candidate target list is empty")
    return sorted(values)


def fasta_accession(header: str) -> str:
    token = header.split()[0]
    if "|" in token:
        parts = token.split("|")
        if len(parts) >= 2:
            return parts[1].upper()
    return token.upper()


def load_fasta_subset(path: Path, wanted: set[str]) -> dict[str, tuple[str, str]]:
    result: dict[str, tuple[str, str]] = {}
    current: str | None = None
    header = ""
    sequence: list[str] = []

    def flush() -> None:
        nonlocal current, header, sequence
        if current is None or current not in wanted:
            return
        joined = "".join(sequence).replace(" ", "").upper()
        if not joined or not re.fullmatch(r"[A-Z*]+", joined):
            raise BuildError(f"invalid FASTA sequence for {current} in {path}")
        if current in result:
            raise BuildError(f"duplicate FASTA accession {current} in {path}")
        result[current] = (header, joined)

    with text_open(path) as handle:
        for raw in handle:
            line = raw.strip()
            if line.startswith(">"):
                flush()
                header = line[1:]
                current = fasta_accession(header)
                sequence = []
            elif current is not None:
                sequence.append(line)
    flush()
    return result


class Ontology:
    def __init__(self, path: Path):
        self.path = path
        self.data_version = ""
        self.namespace: dict[str, str] = {}
        self.parents: dict[str, set[str]] = defaultdict(set)
        self.alt_to_id: dict[str, str] = {}
        self._ancestor_cache: dict[str, frozenset[str]] = {}
        self._parse()

    def _parse(self) -> None:
        header = True
        stanza: dict[str, list[str]] = defaultdict(list)

        def flush() -> None:
            if not stanza or stanza.get("is_obsolete") == ["true"]:
                stanza.clear()
                return
            identifiers = stanza.get("id", [])
            namespaces = stanza.get("namespace", [])
            if len(identifiers) != 1 or len(namespaces) != 1:
                stanza.clear()
                return
            go_id = identifiers[0].split()[0]
            aspect = NAMESPACES.get(namespaces[0])
            if not GO_ID.fullmatch(go_id) or aspect is None:
                stanza.clear()
                return
            self.namespace[go_id] = aspect
            for value in stanza.get("alt_id", []):
                alt = value.split()[0]
                if GO_ID.fullmatch(alt):
                    self.alt_to_id[alt] = go_id
            for value in stanza.get("is_a", []):
                parent = value.split()[0]
                if GO_ID.fullmatch(parent):
                    self.parents[go_id].add(parent)
            for value in stanza.get("relationship", []):
                match = re.match(r"part_of\s+(GO:\d{7})(?:\s|$)", value)
                if match:
                    self.parents[go_id].add(match.group(1))
            stanza.clear()

        for raw in self.path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if header:
                if line.startswith("data-version:"):
                    self.data_version = line.split(":", 1)[1].strip()
                if line == "[Term]":
                    header = False
                else:
                    continue
            if line.startswith("["):
                flush()
                if line != "[Term]":
                    stanza["is_obsolete"] = ["true"]
                continue
            if not line or line.startswith("!"):
                continue
            separator = line.find(":")
            if separator > 0:
                stanza[line[:separator]].append(line[separator + 1 :].strip())
        flush()
        if not self.data_version or not self.namespace:
            raise BuildError(f"invalid GO ontology: {self.path}")
        for child, parents in list(self.parents.items()):
            child_aspect = self.namespace.get(child)
            self.parents[child] = {
                parent for parent in parents if self.namespace.get(parent) == child_aspect
            }

    def canonical(self, go_id: str) -> str | None:
        value = self.alt_to_id.get(go_id, go_id)
        return value if value in self.namespace else None

    def ancestors(self, go_id: str) -> frozenset[str]:
        canonical = self.canonical(go_id)
        if canonical is None:
            return frozenset()
        cached = self._ancestor_cache.get(canonical)
        if cached is not None:
            return cached
        found = {canonical}
        queue = deque([canonical])
        while queue:
            current = queue.popleft()
            for parent in self.parents.get(current, set()):
                if parent not in found:
                    found.add(parent)
                    queue.append(parent)
        value = frozenset(found)
        self._ancestor_cache[canonical] = value
        return value

    def binding_subtree(self) -> set[str]:
        binding = "GO:0005515"
        return {
            term
            for term, aspect in self.namespace.items()
            if aspect == "F" and binding in self.ancestors(term)
        }


def load_t0_terms(path: Path, wanted: set[str], ontology: Ontology) -> dict[str, set[str]]:
    output: dict[str, set[str]] = defaultdict(set)
    with path.open("rt", encoding="utf-8") as handle:
        header = next(handle, "").rstrip("\n").split("\t")
        columns = {name: index for index, name in enumerate(header)}
        if not {"EntryID", "term", "aspect"}.issubset(columns):
            raise BuildError(f"T0 term table has unexpected columns: {header}")
        for raw in handle:
            row = raw.rstrip("\n").split("\t")
            accession = row[columns["EntryID"]].upper()
            if accession not in wanted:
                continue
            go_id = ontology.canonical(row[columns["term"]])
            aspect = row[columns["aspect"]]
            if go_id is not None and ontology.namespace[go_id] == aspect:
                output[accession].add(go_id)
    return output


def flatten_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "|".join(flatten_text(item) for item in value)
    return str(value)


def load_t1_terms(
    path: Path,
    wanted: set[str],
    ontology: Ontology,
) -> tuple[dict[str, set[str]], set[tuple[str, str]], Counter[str]]:
    eligible_rows: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    source_iea: set[tuple[str, str]] = set()
    counters: Counter[str] = Counter()
    with path.open("rt", encoding="utf-8") as handle:
        for line_number, raw in enumerate(handle, start=1):
            try:
                row = json.loads(raw)
            except json.JSONDecodeError as error:
                raise BuildError(f"invalid QuickGO JSONL row {line_number}") from error
            product = str(row.get("geneProductId", ""))
            accession = product.split(":", 1)[-1].split("-", 1)[0].upper()
            if accession not in wanted:
                continue
            qualifier = flatten_text(row.get("qualifier")).upper()
            if "NOT" in qualifier.split("|"):
                counters["not_excluded"] += 1
                continue
            raw_go = str(row.get("goId", ""))
            go_id = ontology.canonical(raw_go)
            if go_id is None:
                counters["unknown_or_obsolete_go"] += 1
                continue
            evidence = str(row.get("goEvidence", "")).upper()
            pair = (accession, go_id)
            aspect = ontology.namespace[go_id]
            source_text = "|".join(
                flatten_text(row.get(key))
                for key in ("withFrom", "reference", "assignedBy")
            ).upper()
            if evidence == "IEA" and (
                (aspect == "C" and "UNIPROTKB-SUBCELL" in source_text)
                or (aspect == "F" and "RHEA" in source_text)
            ):
                source_iea.add(pair)
            if evidence in ELIGIBLE_EVIDENCE:
                eligible_rows[pair].append(row)
                counters[f"evidence_{evidence}"] += 1
            else:
                counters["ineligible_evidence"] += 1
    duplicate_pairs = {
        pair
        for pair, rows in eligible_rows.items()
        if pair in source_iea
        and any(str(row.get("goEvidence", "")).upper() in EXPERIMENTAL_EVIDENCE for row in rows)
    }
    output: dict[str, set[str]] = defaultdict(set)
    for (accession, go_id), rows in eligible_rows.items():
        if rows:
            output[accession].add(go_id)
    return output, duplicate_pairs, counters


def project_and_propagate(
    direct: dict[str, set[str]],
    current: Ontology,
    pivot: Ontology,
) -> dict[str, dict[str, set[str]]]:
    terms_of_interest = set(current.namespace).intersection(pivot.namespace)
    output: dict[str, dict[str, set[str]]] = {}
    for accession, terms in direct.items():
        projected: set[str] = set()
        for term in terms:
            projected.update(current.ancestors(term).intersection(terms_of_interest))
        closed: dict[str, set[str]] = {aspect: set() for aspect in ROOTS}
        for term in projected:
            for ancestor in pivot.ancestors(term):
                aspect = pivot.namespace.get(ancestor)
                if aspect is not None and ancestor != ROOTS[aspect]:
                    closed[aspect].add(ancestor)
        output[accession] = closed
    return output


def load_ia(path: Path, ontology: Ontology) -> dict[str, float]:
    output: dict[str, float] = {}
    with path.open("rt", encoding="utf-8") as handle:
        first = True
        for raw in handle:
            row = raw.strip().split("\t")
            if len(row) < 2:
                continue
            if first and not GO_ID.fullmatch(row[0]):
                first = False
                continue
            first = False
            go_id = ontology.canonical(row[0])
            if go_id is None:
                continue
            value = float(row[1])
            if value < 0:
                raise BuildError(f"negative IA value for {go_id}")
            output[go_id] = value
    missing = set(ontology.namespace) - set(output)
    if missing:
        # LAFA IA is corpus-derived and may omit unused terms.  A zero weight is
        # explicit and neutral for those T0-unobserved terms.
        for go_id in missing:
            output[go_id] = 0.0
    return output


def write_fasta(path: Path, samples: Iterable[tuple[str, str]]) -> None:
    with path.open("wt", encoding="utf-8") as handle:
        for sample_id, sequence in samples:
            handle.write(f">{sample_id}\n")
            for index in range(0, len(sequence), 60):
                handle.write(sequence[index : index + 60] + "\n")


def write_sanitized_ontology(source: Path, destination: Path) -> None:
    """Write the graph-only T0 ontology admitted to the inner evidence plane.

    GO OBO releases include prose examples and cross-references that can name
    concrete UniProt accessions. Those fields are unnecessary for true-path
    closure, so the admitted file retains only term identity, display name,
    namespace, aliases, and the two safe graph relations used by the evaluator.
    """
    header: list[str] = []
    terms: list[list[str]] = []
    stanza: list[str] = []
    stanza_kind = ""

    def flush() -> None:
        nonlocal stanza
        if stanza_kind != "Term" or not stanza:
            stanza = []
            return
        fields: dict[str, list[str]] = defaultdict(list)
        for line in stanza:
            key, separator, value = line.partition(":")
            if separator:
                fields[key].append(value.strip())
        if fields.get("is_obsolete") == ["true"]:
            stanza = []
            return
        retained: list[str] = []
        for key in ("id", "name", "namespace", "alt_id", "is_a"):
            retained.extend(f"{key}: {value}" for value in fields.get(key, []))
        retained.extend(
            f"relationship: {value}"
            for value in fields.get("relationship", [])
            if re.match(r"part_of\s+GO:\d{7}(?:\s|$)", value)
        )
        if len(fields.get("id", [])) == 1 and len(fields.get("namespace", [])) == 1:
            terms.append(retained)
        stanza = []

    for raw in source.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line.startswith("[") and line.endswith("]"):
            flush()
            stanza_kind = line[1:-1]
            continue
        if stanza_kind:
            if line:
                stanza.append(line)
            continue
        if line.startswith(("format-version:", "data-version:", "default-namespace:", "ontology:")):
            header.append(line)
    flush()
    destination.write_text(
        "\n".join(header)
        + "\n\n"
        + "\n\n".join("[Term]\n" + "\n".join(term) for term in terms)
        + "\n",
        encoding="utf-8",
    )


def build(args: argparse.Namespace) -> int:
    paths = {name: Path(getattr(args, name)).resolve() for name in (
        "targets", "t0_fasta", "t0_search_fasta", "t1_fasta", "t0_terms", "t0_ontology",
        "t1_ontology", "t0_ia", "quickgo_manifest", "quickgo_annotations",
    )}
    output = Path(args.output).resolve()
    if output.exists():
        if not args.overwrite:
            raise BuildError(f"output already exists: {output}")
        if output.is_symlink() or not output.is_dir():
            raise BuildError(f"refusing to overwrite non-directory output: {output}")
        shutil.rmtree(output)
    public = output / "public"
    private = output / "evaluator_private"
    evaluation = output / "evaluation"
    public.mkdir(parents=True)
    private.mkdir(parents=True, mode=0o700)
    evaluation.mkdir(parents=True)

    targets = load_targets(paths["targets"])
    wanted = set(targets)
    t0_sequences = load_fasta_subset(paths["t0_fasta"], wanted)
    t1_sequences = load_fasta_subset(paths["t1_fasta"], wanted)
    missing_t0 = wanted - set(t0_sequences)
    missing_t1 = wanted - set(t1_sequences)
    changed = {
        accession
        for accession in wanted.intersection(t0_sequences, t1_sequences)
        if t0_sequences[accession][1] != t1_sequences[accession][1]
    }
    stable = sorted(wanted - missing_t0 - missing_t1 - changed)
    if not stable:
        raise BuildError("no sequence-stable candidate targets remain")

    t0_ontology = Ontology(paths["t0_ontology"])
    t1_ontology = Ontology(paths["t1_ontology"])
    public_ontology_path = public / "go-basic.obo"
    write_sanitized_ontology(paths["t0_ontology"], public_ontology_path)
    public_ontology = Ontology(public_ontology_path)
    if (
        public_ontology.data_version != t0_ontology.data_version
        or public_ontology.namespace != t0_ontology.namespace
        or public_ontology.parents != t0_ontology.parents
        or public_ontology.alt_to_id != t0_ontology.alt_to_id
    ):
        raise BuildError("sanitized public ontology does not preserve the T0 scoring graph")
    public_ontology_text = public_ontology_path.read_text(encoding="utf-8")
    leaked_accessions = set(
        re.findall(r"(?<![A-Z0-9])[A-Z0-9]{6,10}(?![A-Z0-9])", public_ontology_text)
    ).intersection(stable)
    if leaked_accessions:
        raise BuildError(
            "sanitized public ontology contains candidate accessions: "
            + ", ".join(sorted(leaked_accessions)[:5])
        )
    t0_direct = load_t0_terms(paths["t0_terms"], set(stable), t0_ontology)
    quickgo_manifest = json.loads(paths["quickgo_manifest"].read_text(encoding="utf-8"))
    expected_hash = quickgo_manifest.get("annotationFile", {}).get("sha256")
    if expected_hash != sha256_file(paths["quickgo_annotations"]):
        raise BuildError("QuickGO annotation snapshot hash does not match its manifest")
    if quickgo_manifest.get("targetSource", {}).get("targetCount") != len(targets):
        raise BuildError("QuickGO snapshot target count does not match the candidate universe")
    t1_direct, duplicate_pairs, t1_counters = load_t1_terms(
        paths["quickgo_annotations"], set(stable), t1_ontology
    )
    applicable_duplicate_pairs = {
        (accession, go_id)
        for accession, go_id in duplicate_pairs
        if go_id not in t0_direct.get(accession, set())
    }
    for accession, go_id in applicable_duplicate_pairs:
        t1_direct[accession].discard(go_id)
    t1_counters["source_reclassification_pairs_removed"] = len(applicable_duplicate_pairs)
    t0_closed = project_and_propagate(t0_direct, t0_ontology, t0_ontology)
    t1_closed = project_and_propagate(t1_direct, t1_ontology, t0_ontology)
    binding = t0_ontology.binding_subtree()
    binding_branch = binding.union(t0_ontology.ancestors("GO:0005515")) - {ROOTS["F"]}
    ia = load_ia(paths["t0_ia"], t0_ontology)

    sample_by_accession = {
        accession: f"Z69T{index:05d}" for index, accession in enumerate(stable, start=1)
    }
    gold_cases: list[dict[str, Any]] = []
    exclusions: list[tuple[str, str]] = []
    subset_counts: Counter[str] = Counter()
    aspect_counts: Counter[str] = Counter()
    gold_rows: dict[str, list[tuple[str, str, str]]] = {key: [] for key in ("NK", "LK", "PK")}
    pk_known_rows: list[tuple[str, str, str]] = []

    for accession in stable:
        known = t0_closed.get(accession, {aspect: set() for aspect in ROOTS})
        current = t1_closed.get(accession, {aspect: set() for aspect in ROOTS})
        no_knowledge = not any(known[aspect] for aspect in ROOTS)
        scored_aspects: list[str] = []
        terms: list[dict[str, str]] = []
        known_terms: list[dict[str, str]] = []
        subset_by_aspect: dict[str, str] = {}
        for aspect in ("F", "P", "C"):
            current_terms = set(current[aspect])
            if aspect == "F" and current_terms and current_terms.issubset(binding_branch):
                continue
            gained = current_terms if no_knowledge else current_terms - known[aspect]
            if not gained:
                continue
            subset = "NK" if no_knowledge else ("PK" if known[aspect] else "LK")
            scored_aspects.append(ASPECT_NAMES[aspect])
            subset_by_aspect[ASPECT_NAMES[aspect]] = subset
            subset_counts[subset] += 1
            aspect_counts[aspect] += 1
            if subset == "PK":
                for go_id in sorted(known[aspect]):
                    known_terms.append({"goId": go_id, "aspect": ASPECT_NAMES[aspect]})
                    pk_known_rows.append((sample_by_accession[accession], go_id, aspect))
            for go_id in sorted(gained):
                terms.append({"goId": go_id, "aspect": ASPECT_NAMES[aspect]})
                gold_rows[subset].append((sample_by_accession[accession], go_id, aspect))
        if scored_aspects:
            gold_cases.append(
                {
                    "proteinId": sample_by_accession[accession],
                    "scoredAspects": scored_aspects,
                    "subsetByAspect": subset_by_aspect,
                    "terms": terms,
                    "knownTerms": known_terms,
                }
            )
        else:
            exclusions.append((accession, "no_eligible_T1_gain_after_projection"))

    source_records = [
        {"role": role, **source_record(path, label)}
        for role, label, path in (
            ("candidate_ids", "LAFA Sep-2025 -> Mar-2026 candidate IDs", paths["targets"]),
            ("t0_target_fasta", "LAFA Sep-2025 reviewed target-universe sequences", paths["t0_fasta"]),
            ("t0_sequence_fasta", "LAFA Sep-2025 eligible annotated search sequences", paths["t0_search_fasta"]),
            ("t1_sequence_fasta", "UniProt 2026_02 reviewed sequences", paths["t1_fasta"]),
            ("t0_annotation_terms", "LAFA Sep-2025 eligible T0 terms", paths["t0_terms"]),
            ("t0_ontology", "LAFA Sep-2025 GO ontology", paths["t0_ontology"]),
            ("t1_ontology", "T1 GO ontology", paths["t1_ontology"]),
            ("t0_information_accretion", "LAFA Sep-2025 information accretion", paths["t0_ia"]),
            ("t1_annotation_manifest", "T1 QuickGO snapshot manifest", paths["quickgo_manifest"]),
            ("t1_annotations", "T1 QuickGO normalized annotations", paths["quickgo_annotations"]),
        )
    ]
    source_by_role = {record["role"]: record for record in source_records}
    inner_resources = [
        source_by_role["t0_sequence_fasta"],
        source_by_role["t0_annotation_terms"],
        {
            "role": "t0_ontology",
            **source_record(
                public_ontology_path,
                "sanitized LAFA Sep-2025 GO graph (no prose examples or cross-references)",
            ),
        },
        source_by_role["t0_information_accretion"],
    ]

    inner_contract = with_hash(
        {
            "schemaVersion": "pi-temporal-inner-resource-contract.v1",
            "suiteId": args.suite_id,
            "mode": "strict_t0_evidence_plane",
            "t0Label": "LAFA Sep_2025",
            "allowed": {
                "networkEvidenceProviders": False,
                "httpEvidenceBackend": False,
                "sequenceSearchBackend": "local",
                "structureSearchBackend": "local",
                "candidateProviderMode": "disabled",
                "currentDatabaseLookup": False,
            },
            "resources": inner_resources,
            "note": (
                "The language-model transport may still require network access. Isolation applies to the "
                "biological evidence/tool plane: the inner narrative agents receive only the frozen evidence bundle."
            ),
        }
    )

    public_manifest = with_hash(
        {
            "schemaVersion": SCHEMA,
            "suiteId": args.suite_id,
            "benchmarkKind": "retrospective_lafa_derived_temporal_evaluation",
            "t0": {
                "label": "LAFA Sep_2025",
                "goaGeneratedAt": "2025-09-04T16:09:00Z",
                "goaGoVersion": "2025-08-31",
                "uniprotRelease": "2025_03",
                "uniprotReleaseDate": "2025-06-18",
                "evaluationOntologyDataVersion": t0_ontology.data_version,
            },
            "t1": {
                "annotationSnapshot": "QuickGO target-bounded API snapshot",
                "annotationAcquiredAt": quickgo_manifest.get("acquiredAt"),
                "officialGoaReferenceGeneratedAt": args.t1_goa_generated_at,
                "officialGoaReferenceMd5": args.t1_goa_md5,
                "uniprotRelease": "2026_02",
                "uniprotReleaseDate": "2026-06-10",
                "goOntologyDataVersion": t1_ontology.data_version,
            },
            "cohort": {
                "candidatePolicy": "published LAFA Sep-2025 -> Mar-2026 target universe",
                "candidateCount": len(targets),
                "predictionTargetPolicy": "candidate present at T0 and T1 with byte-identical canonical sequence",
                "predictionTargetCount": len(stable),
                "scoredTargetCount": len(gold_cases),
                "selectionUsesT1Gold": False,
                "scoringMaskUsesT1Gold": True,
            },
            "publicFiles": {
                "targetsFasta": "targets.fasta",
                "predictionTemplate": "prediction_template.tsv",
                "informationAccretion": "IA.tsv",
                "evaluationOntology": "go-basic.obo",
                "evaluationOntologyProjection": (
                    "graph-preserving T0 projection: id/name/namespace/alt_id/is_a/part_of only"
                ),
                "innerResourceContract": "inner_resource_contract.json",
                "innerResourceContractHash": inner_contract["canonicalHash"],
            },
            "predictionFormat": {
                "columns": ["target_id", "go_id", "score"],
                "scoreRange": [0.0, 1.0],
                "oneBasedMeaning": "higher confidence",
            },
            "goldPolicy": {
                "eligibleEvidence": sorted(ELIGIBLE_EVIDENCE),
                "negatedAnnotationsExcluded": True,
                "relations": ["is_a", "part_of"],
                "futureTermsProjectedToT0Universe": True,
                "rootsExcluded": True,
                "bindingOnlyMfExcluded": True,
                "sourceReclassificationRule": "remove experimental protein-GO pairs also present as UniProtKB-SubCell IEA (CC) or RHEA IEA (MF)",
                "subsets": {
                    "NK": "no eligible T0 annotation in any aspect; score all projected T1 terms in gained aspects",
                    "LK": "T1 gain in an aspect absent at T0",
                    "PK": "T1 gain in an aspect already annotated at T0",
                },
            },
            "fairness": {
                "pairedTargetAndGoldForAllMethods": True,
                "fixedT0ResourceBudget": True,
                "latestResourcesForbiddenInsidePredictor": True,
                "outerRsiMayUseCurrentNetworkResources": True,
                "claimBoundary": (
                    "Fair for paired retrospective comparison under the same frozen T0 evidence plane. "
                    "Not a fresh prospective CAFA challenge: the seed candidate universe was originally "
                    "selected by LAFA after observing Sep-2025 -> Mar-2026 gains."
                ),
            },
        }
    )
    write_json(public / "manifest.json", public_manifest)
    write_fasta(
        public / "targets.fasta",
        ((sample_by_accession[accession], t0_sequences[accession][1]) for accession in stable),
    )
    (public / "prediction_template.tsv").write_text("target_id\tgo_id\tscore\n", encoding="utf-8")
    shutil.copyfile(paths["t0_ia"], public / "IA.tsv")

    write_json(public / "inner_resource_contract.json", inner_contract)

    gold_document = with_hash(
        {
            "schemaVersion": GOLD_SCHEMA,
            "suiteId": args.suite_id,
            "publicManifestHash": public_manifest["canonicalHash"],
            "partitionId": "t1_gain_scoring_mask",
            "cases": gold_cases,
        }
    )
    write_json(private / "gold.json", gold_document, private=True)
    (private / "identity_map.tsv").write_text(
        "target_id\taccession\n"
        + "".join(f"{sample_by_accession[item]}\t{item}\n" for item in stable),
        encoding="utf-8",
    )
    (private / "identity_map.tsv").chmod(0o600)
    for subset, rows in gold_rows.items():
        path = private / f"groundtruth_{subset}.tsv"
        path.write_text(
            "target_id\tgo_id\taspect\n"
            + "".join(f"{sample}\t{go_id}\t{aspect}\n" for sample, go_id, aspect in sorted(set(rows))),
            encoding="utf-8",
        )
        path.chmod(0o600)
    pk_known_path = private / "groundtruth_PK_known.tsv"
    pk_known_path.write_text(
        "target_id\tgo_id\taspect\n"
        + "".join(
            f"{sample}\t{go_id}\t{aspect}\n"
            for sample, go_id, aspect in sorted(set(pk_known_rows))
        ),
        encoding="utf-8",
    )
    pk_known_path.chmod(0o600)
    (private / "candidate_exclusions.tsv").write_text(
        "accession\treason\n"
        + "".join(f"{item}\tmissing_at_T0\n" for item in sorted(missing_t0))
        + "".join(f"{item}\tmissing_at_T1\n" for item in sorted(missing_t1))
        + "".join(f"{item}\tsequence_changed\n" for item in sorted(changed))
        + "".join(f"{item}\t{reason}\n" for item, reason in exclusions),
        encoding="utf-8",
    )
    (private / "candidate_exclusions.tsv").chmod(0o600)

    audit = with_hash(
        {
            "schemaVersion": "pi-lafa-temporal-build-audit.v1",
            "suiteId": args.suite_id,
            "publicManifestHash": public_manifest["canonicalHash"],
            "sourceFiles": source_records,
            "counts": {
                "candidate": len(targets),
                "missingAtT0": len(missing_t0),
                "missingAtT1": len(missing_t1),
                "sequenceChanged": len(changed),
                "sequenceStablePredictionTargets": len(stable),
                "scoredTargets": len(gold_cases),
                "unscoredStableTargets": len(stable) - len(gold_cases),
                "scoredProteinAspectPairs": sum(aspect_counts.values()),
                "goldTerms": sum(len(item["terms"]) for item in gold_cases),
                "sourceReclassificationPairsObserved": len(duplicate_pairs),
                "sourceReclassificationGainedPairsRemoved": len(applicable_duplicate_pairs),
                "subsetProteinAspectPairs": dict(sorted(subset_counts.items())),
                "aspectProteinPairs": dict(sorted(aspect_counts.items())),
                "t1AnnotationFilter": dict(sorted(t1_counters.items())),
            },
        }
    )
    write_json(private / "build_audit.json", audit, private=True)

    evaluation_protocol = with_hash(
        {
            "schemaVersion": "pi-lafa-temporal-evaluation-protocol.v1",
            "suiteId": args.suite_id,
            "publicManifestHash": public_manifest["canonicalHash"],
            "scoringUnit": "protein within evaluator-declared aspect mask",
            "ontology": {
                "source": "public/go-basic.obo",
                "dataVersion": t0_ontology.data_version,
                "sha256": sha256_file(public / "go-basic.obo"),
                "truePathClosure": "is_a and part_of, same namespace, roots excluded, symmetric for gold and predictions",
            },
            "metrics": {
                "Fmax": "CAFA protein-centric precision/recall; threshold optimized on the reported partition",
                "AUPR": "trapezoidal area over the same protein-centric precision/recall threshold curve",
                "IA-wFmax": "micro Fmax after weighting every term by frozen T0 LAFA information accretion (cafaeval f_micro_w convention)",
                "Smin": "minimum Euclidean distance between mean remaining uncertainty and misinformation using frozen T0 IA",
                "nSmin": (
                    "minimum Euclidean distance between mean per-protein normalized remaining uncertainty "
                    "and misinformation; each protein is normalized by IA(gold union prediction)"
                ),
            },
            "reporting": ["overall", "molecular_function", "biological_process", "cellular_component", "NK", "LK", "PK"],
            "comparison": "paired target/aspect bootstrap is recommended for inferential method comparisons; point tables must use the exact shared mask",
            "primaryAnalysis": "all scored protein-aspect pairs; NK/LK/PK are stratified secondary analyses",
        }
    )
    write_json(evaluation / "protocol.json", evaluation_protocol)
    (evaluation / "README.md").write_text(
        "# Evaluation\n\n"
        "Submit `target_id<TAB>go_id<TAB>score` rows using IDs from `public/targets.fasta`. "
        "Run `python3 evaluate_lafa_temporal_benchmark.py --benchmark <suite> "
        "--predictions predictions.tsv --output report.json`. Missing rows are abstentions.\n",
        encoding="utf-8",
    )
    summary = {
        "ok": True,
        "output": str(output),
        "suiteId": args.suite_id,
        "publicManifestHash": public_manifest["canonicalHash"],
        "candidateCount": len(targets),
        "predictionTargetCount": len(stable),
        "scoredTargetCount": len(gold_cases),
        "scoredProteinAspectPairs": sum(aspect_counts.values()),
        "goldTermCount": sum(len(item["terms"]) for item in gold_cases),
        "subsetProteinAspectPairs": dict(sorted(subset_counts.items())),
        "aspectProteinPairs": dict(sorted(aspect_counts.items())),
    }
    write_json(output / "build_summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--targets", required=True)
    value.add_argument("--t0-fasta", required=True)
    value.add_argument("--t0-search-fasta", required=True)
    value.add_argument("--t1-fasta", required=True)
    value.add_argument("--t0-terms", required=True)
    value.add_argument("--t0-ontology", required=True)
    value.add_argument("--t1-ontology", required=True)
    value.add_argument("--t0-ia", required=True)
    value.add_argument("--quickgo-manifest", required=True)
    value.add_argument("--quickgo-annotations", required=True)
    value.add_argument("--output", required=True)
    value.add_argument("--suite-id", default="z69-lafa-sep2025-to-quickgo-20260801-v1")
    value.add_argument("--t1-goa-generated-at", default="2026-07-29T13:39:00Z")
    value.add_argument("--t1-goa-md5", default="a6317d20f08ac68a3ebf867e5af33f8c")
    value.add_argument("--overwrite", action="store_true")
    return value


if __name__ == "__main__":
    raise SystemExit(build(parser().parse_args()))
