#!/usr/bin/env python3
"""Run feasible offline LAFA-style baselines on a derived temporal pilot."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

from build_lafa_temporal_benchmark import GO_ID, ROOTS, Ontology, canonical_bytes

LAFA_GUIDE_COMMIT = "54d81d22f451c00de81b9f0a22d54e1320974e6f"

class BaselineError(RuntimeError):
    pass


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def with_hash(value: dict[str, Any]) -> dict[str, Any]:
    output = dict(value)
    output["canonicalHash"] = hashlib.sha256(canonical_bytes(output)).hexdigest()
    return output


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")


def read_fasta(path: Path) -> dict[str, str]:
    output: dict[str, str] = {}
    identifier: str | None = None
    sequence: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        if raw.startswith(">"):
            if identifier is not None:
                output[identifier] = "".join(sequence)
            identifier = raw[1:].split()[0]
            if identifier in output:
                raise BaselineError(f"duplicate FASTA identifier: {identifier}")
            sequence = []
        elif raw.strip():
            if identifier is None:
                raise BaselineError("sequence found before FASTA header")
            sequence.append(raw.strip())
    if identifier is not None:
        output[identifier] = "".join(sequence)
    return output


def run_command(
    command: list[str],
    cwd: Path | None = None,
    timeout: int = 3600,
    path_prefix: Path | None = None,
) -> dict[str, Any]:
    started = time.monotonic()
    environment = os.environ.copy()
    if path_prefix is not None:
        environment["PATH"] = f"{path_prefix}{os.pathsep}{environment.get('PATH', '')}"
    result = subprocess.run(
        command,
        cwd=cwd,
        text=True,
        capture_output=True,
        timeout=timeout,
        check=False,
        env=environment,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout)[-4000:]
        raise BaselineError(f"command failed ({result.returncode}): {' '.join(command)}\n{detail}")
    return {
        "command": command,
        "pathPrefix": str(path_prefix) if path_prefix is not None else None,
        "durationSeconds": round(time.monotonic() - started, 3),
        "stdoutTail": result.stdout[-2000:],
        "stderrTail": result.stderr[-2000:],
    }


def prediction_stats(path: Path) -> dict[str, Any]:
    targets: set[str] = set()
    rows = 0
    with path.open("rt", encoding="utf-8") as handle:
        if next(handle, "").rstrip("\n") != "target_id\tgo_id\tscore":
            raise BaselineError(f"invalid prediction header: {path}")
        for raw in handle:
            if not raw.strip():
                continue
            row = raw.rstrip("\n").split("\t")
            if len(row) != 3:
                raise BaselineError(f"invalid prediction row in {path}")
            targets.add(row[0])
            rows += 1
    return {
        "file": path.name,
        "sizeBytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "rowCount": rows,
        "predictedTargetCount": len(targets),
    }


def write_predictions(path: Path, rows: Iterable[tuple[str, str, float]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wt", encoding="utf-8") as handle:
        handle.write("target_id\tgo_id\tscore\n")
        for target_id, go_id, score in rows:
            if not math.isfinite(score) or score <= 0 or score > 1:
                raise BaselineError(f"invalid score for {target_id} {go_id}: {score}")
            handle.write(f"{target_id}\t{go_id}\t{score:.9g}\n")


def load_identity_map(path: Path) -> tuple[dict[str, str], dict[str, str]]:
    rows = path.read_text(encoding="utf-8").splitlines()
    if not rows or rows[0] != "target_id\taccession":
        raise BaselineError("identity map header is invalid")
    target_to_accession: dict[str, str] = {}
    for raw in rows[1:]:
        if not raw:
            continue
        target_id, accession = raw.split("\t")
        target_to_accession[target_id] = accession
    return target_to_accession, {value: key for key, value in target_to_accession.items()}


def naive_predictions(
    targets: list[str], propagated_terms: Path, ontology: Ontology, output: Path
) -> dict[str, Any]:
    term_counts: Counter[str] = Counter()
    root_counts: Counter[str] = Counter()
    term_aspect: dict[str, str] = {}
    with propagated_terms.open("rt", encoding="utf-8") as handle:
        header = next(handle, "").rstrip("\n").split("\t")
        if header != ["EntryID", "term", "aspect"]:
            raise BaselineError("propagated training-term header is invalid")
        for raw in handle:
            _, raw_go, aspect = raw.rstrip("\n").split("\t")
            go_id = ontology.canonical(raw_go)
            if go_id is None:
                continue
            term_counts[go_id] += 1
            term_aspect[go_id] = aspect
            if go_id == ROOTS[aspect]:
                root_counts[aspect] += 1
    if set(root_counts) != set(ROOTS):
        raise BaselineError("propagated training terms do not contain all aspect roots")
    scores = [
        (go_id, count / root_counts[term_aspect[go_id]])
        for go_id, count in term_counts.items()
        if go_id != ROOTS[term_aspect[go_id]] and root_counts[term_aspect[go_id]] > 0
    ]
    scores.sort(key=lambda item: item[0])
    write_predictions(
        output,
        ((target_id, go_id, score) for target_id in targets for go_id, score in scores),
    )
    return {
        "algorithm": "LAFA aspect-normalized propagated T0 term frequency",
        "reference": f"LAFA_container_guide@{LAFA_GUIDE_COMMIT}/baselines/naive_container",
        "trainingTermCount": sum(term_counts.values()),
        "predictedTermVocabulary": len(scores),
        "rootProteinCounts": dict(sorted(root_counts.items())),
    }


def transfer_predictions(
    hits_path: Path, annotation_store: Path, ontology: Ontology, output: Path
) -> dict[str, Any]:
    best_subject: dict[tuple[str, str], tuple[float, float]] = {}
    raw_hits = 0
    with hits_path.open("rt", encoding="utf-8") as handle:
        for raw in handle:
            if not raw.strip():
                continue
            row = raw.rstrip("\n").split("\t")
            if len(row) < 5:
                raise BaselineError(f"search output has fewer than five columns: {hits_path}")
            query = row[0].split("|", 2)[1] if "|" in row[0] else row[0]
            subject = row[1].split("|", 2)[1] if "|" in row[1] else row[1]
            evalue = float(row[2])
            pident = float(row[4])
            raw_hits += 1
            key = (query, subject)
            previous = best_subject.get(key)
            if previous is None or (pident, -evalue) > (previous[0], -previous[1]):
                best_subject[key] = (pident, evalue)

    donors = sorted({subject for _, subject in best_subject})
    donor_terms: dict[str, list[str]] = defaultdict(list)
    connection = sqlite3.connect(f"file:{annotation_store.resolve()}?mode=ro", uri=True)
    try:
        for offset in range(0, len(donors), 800):
            batch = donors[offset:offset + 800]
            placeholders = ",".join("?" for _ in batch)
            for accession, raw_go in connection.execute(
                f"SELECT accession, go_id FROM annotations WHERE accession IN ({placeholders})",
                batch,
            ):
                go_id = ontology.canonical(str(raw_go))
                if go_id is not None and go_id != ROOTS[ontology.namespace[go_id]]:
                    donor_terms[str(accession)].append(go_id)
    finally:
        connection.close()

    scores: dict[tuple[str, str], float] = {}
    queries_with_annotated_hits: set[str] = set()
    for (query, subject), (pident, _) in best_subject.items():
        terms = donor_terms.get(subject, [])
        if terms:
            queries_with_annotated_hits.add(query)
        score = min(1.0, max(0.0, pident / 100.0))
        for go_id in terms:
            key = (query, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((query, go_id, score) for (query, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": "multi-donor per-term maximum local alignment identity",
        "termScore": "max(pident / 100) across T0 donors carrying the direct GO term",
        "rawHitCount": raw_hits,
        "deduplicatedQuerySubjectCount": len(best_subject),
        "uniqueDonorCount": len(donors),
        "annotatedDonorCount": sum(bool(donor_terms.get(item)) for item in donors),
        "queriesWithAnnotatedHits": len(queries_with_annotated_hits),
    }


def normalize_deepgoplus(
    raw_path: Path, output: Path, allowed_targets: set[str], ontology: Ontology
) -> dict[str, Any]:
    scores: dict[tuple[str, str], float] = {}
    skipped = 0
    with raw_path.open("rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            row = raw.rstrip("\n").split("\t")
            if not row or row[0] not in allowed_targets:
                skipped += 1
                continue
            fields: list[tuple[str, str]] = []
            if len(row) == 3 and GO_ID.fullmatch(row[1]):
                fields.append((row[1], row[2]))
            else:
                for item in row[1:]:
                    raw_go, separator, raw_score = item.partition("|")
                    if not separator:
                        skipped += 1
                        continue
                    fields.append((raw_go, raw_score))
            for raw_go, raw_score in fields:
                go_id = ontology.canonical(raw_go)
                if go_id is None or go_id == ROOTS[ontology.namespace[go_id]]:
                    skipped += 1
                    continue
                try:
                    score = float(raw_score)
                except ValueError:
                    skipped += 1
                    continue
                if not math.isfinite(score) or score <= 0:
                    continue
                key = (row[0], go_id)
                scores[key] = max(scores.get(key, 0.0), min(1.0, score))
    write_predictions(output, ((q, go, score) for (q, go), score in sorted(scores.items())))
    return {"normalizedRows": len(scores), "skippedRawRows": skipped}


def evaluate_method(repo: Path, pilot: Path, method_dir: Path) -> dict[str, Any]:
    report = method_dir / "metrics.json"
    command = [
        sys.executable,
        str(repo / "scripts/evaluate_lafa_temporal_benchmark.py"),
        "--benchmark", str(pilot),
        "--predictions", str(method_dir / "predictions.tsv"),
        "--output", str(report),
    ]
    execution = run_command(command, cwd=repo, timeout=3600)
    return {"execution": execution, "report": json.loads(report.read_text(encoding="utf-8"))}


def method_receipt(
    method_dir: Path,
    suite_id: str,
    method: str,
    implementation: dict[str, Any],
    executions: list[dict[str, Any]],
    metrics: dict[str, Any],
    t0_only_evidence: bool = True,
) -> dict[str, Any]:
    receipt = with_hash({
        "schemaVersion": "pi-lafa-temporal-pilot-baseline-run.v1",
        "suiteId": suite_id,
        "method": method,
        "offline": True,
        "t0OnlyEvidence": t0_only_evidence,
        "temporalEligibility": "formal_t0" if t0_only_evidence else "post_t0_diagnostic_only",
        "implementation": implementation,
        "executions": executions,
        "prediction": prediction_stats(method_dir / "predictions.tsv"),
        "metricReportHash": metrics["canonicalHash"],
    })
    write_json(method_dir / "run_receipt.json", receipt)
    return receipt


def main(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    pilot = Path(args.pilot).resolve()
    benchmark_root = Path(args.benchmark_root).resolve()
    public = pilot / "public"
    private = pilot / "evaluator_private"
    output = pilot / "results"
    if output.exists() and any(output.iterdir()):
        if not args.overwrite:
            raise BaselineError(f"results already exist: {output}")
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    manifest = json.loads((public / "manifest.json").read_text(encoding="utf-8"))
    targets = list(read_fasta(public / "targets.fasta"))
    target_set = set(targets)
    target_to_accession, accession_to_target = load_identity_map(private / "identity_map.tsv")
    if set(target_to_accession) != target_set:
        raise BaselineError("pilot identity map and public FASTA differ")
    ontology = Ontology(public / "go-basic.obo")
    t0 = benchmark_root / "sources/t0/Sep_2025"
    annotation_store = benchmark_root / "resources/t0_annotations.sqlite3"
    blast_db = benchmark_root / "resources/blast/lafa_sep2025"
    blastp = Path(args.blastp).resolve()
    diamond = Path(args.diamond).resolve()
    mmseqs = Path(args.mmseqs).resolve()
    for path in (annotation_store, t0 / "train_sequences.fasta", t0 / "train_terms_propagated.tsv", t0 / "goa_uniprot_sprot.gaf.gz"):
        if not path.exists():
            raise BaselineError(f"required T0 resource is missing: {path}")

    receipts: dict[str, Any] = {}
    metric_reports: dict[str, dict[str, Any]] = {}

    def finish(
        method: str,
        implementation: dict[str, Any],
        executions: list[dict[str, Any]],
        t0_only_evidence: bool = True,
    ) -> None:
        method_dir = output / method
        evaluated = evaluate_method(repo, pilot, method_dir)
        executions.append(evaluated["execution"])
        metric_reports[method] = evaluated["report"]
        receipts[method] = method_receipt(
            method_dir,
            manifest["suiteId"],
            method,
            implementation,
            executions,
            evaluated["report"],
            t0_only_evidence,
        )

    method_dir = output / "lafa_naive"
    implementation = naive_predictions(
        targets, t0 / "train_terms_propagated.tsv", ontology, method_dir / "predictions.tsv"
    )
    finish("lafa_naive", implementation, [])

    searches: list[tuple[str, list[str], dict[str, Any]]] = []
    blast_hits = output / "blastp_go_transfer/work/hits.tsv"
    blast_hits.parent.mkdir(parents=True, exist_ok=True)
    blast_command = [
        str(blastp), "-query", str(public / "targets.fasta"), "-db", str(blast_db),
        "-out", str(blast_hits), "-outfmt", "6 qseqid sseqid evalue length pident nident qlen slen",
        "-evalue", "10", "-max_target_seqs", "500", "-num_threads", str(args.threads),
    ]
    searches.append(("blastp_go_transfer", blast_command, {
        "reference": f"LAFA_container_guide@{LAFA_GUIDE_COMMIT}/baselines/blast_container",
        "binary": str(blastp),
    }))

    diamond_dir = output / "diamond_go_transfer/work"
    diamond_dir.mkdir(parents=True, exist_ok=True)
    diamond_db = diamond_dir / "lafa_sep2025"
    diamond_make = [str(diamond), "makedb", "--in", str(t0 / "train_sequences.fasta"), "--db", str(diamond_db)]
    diamond_hits = diamond_dir / "hits.tsv"
    diamond_search = [
        str(diamond), "blastp", "--query", str(public / "targets.fasta"), "--db", str(diamond_db),
        "--out", str(diamond_hits), "--outfmt", "6", "qseqid", "sseqid", "evalue", "length", "pident", "nident", "qlen", "slen",
        "--evalue", "10", "--max-target-seqs", "500", "--threads", str(args.threads),
    ]
    diamond_executions = [run_command(diamond_make, cwd=repo, timeout=1800)]
    searches.append(("diamond_go_transfer", diamond_search, {
        "reference": "DIAMOND replacement for the LAFA BLAST homology-transfer search",
        "binary": str(diamond),
        "databaseSha256": sha256_file(diamond_db.with_suffix(".dmnd")),
        "preExecutions": diamond_executions,
    }))

    mmseqs_dir = output / "mmseqs2_go_transfer/work"
    mmseqs_dir.mkdir(parents=True, exist_ok=True)
    mmseqs_hits = mmseqs_dir / "hits.tsv"
    mmseqs_search = [
        str(mmseqs), "easy-search", str(public / "targets.fasta"), str(t0 / "train_sequences.fasta"),
        str(mmseqs_hits), str(mmseqs_dir / "tmp"), "--format-output",
        "query,target,evalue,alnlen,pident,nident,qlen,tlen", "--max-seqs", "500",
        "--threads", str(args.threads),
    ]
    searches.append(("mmseqs2_go_transfer", mmseqs_search, {
        "reference": "MMseqs2 search with the same multi-donor GO-transfer rule as LAFA BLAST",
        "binary": str(mmseqs),
    }))

    for method, command, details in searches:
        method_dir = output / method
        execution_prefix = list(details.pop("preExecutions", []))
        execution = run_command(command, cwd=repo, timeout=3600)
        hits = method_dir / "work/hits.tsv"
        implementation = {
            **details,
            **transfer_predictions(hits, annotation_store, ontology, method_dir / "predictions.tsv"),
            "searchDatabase": "LAFA Sep-2025 train_sequences",
            "annotationStore": "LAFA Sep-2025 direct train_terms",
        }
        finish(method, implementation, [*execution_prefix, execution])

    deepgo_dir = output / "deepgoplus_1_0_2"
    deepgo_dir.mkdir(parents=True, exist_ok=True)
    deepgo_raw = deepgo_dir / "work/raw_predictions.tsv"
    deepgo_raw.parent.mkdir(parents=True, exist_ok=True)
    deepgo_data = Path(args.deepgoplus_data).resolve()
    deepgo_command = [
        args.deepgoplus_executable,
        "--data-root", str(deepgo_data),
        "--in-file", str(public / "targets.fasta"),
        "--out-file", str(deepgo_raw),
        "--threshold", "0.01",
    ]
    deepgo_execution = run_command(
        deepgo_command,
        cwd=repo,
        timeout=3600,
        path_prefix=diamond.parent,
    )
    deepgo_metadata_path = deepgo_data / "metadata/last_release.json"
    deepgo_metadata = json.loads(deepgo_metadata_path.read_text(encoding="utf-8"))
    deepgo_data_release = str(deepgo_metadata.get("version", ""))
    deepgo_uniprot_release = str(deepgo_metadata.get("current_uniprot_version", ""))
    t0_uniprot_release = str(
        manifest.get("parentTemporalContract", {}).get("t0", {}).get("uniprotRelease", "")
    )
    if not deepgo_uniprot_release or not t0_uniprot_release:
        raise BaselineError("cannot establish DeepGOPlus and benchmark UniProt release dates")
    deepgo_t0_eligible = deepgo_uniprot_release <= t0_uniprot_release
    implementation = {
        "reference": "FunctionBench/LAFA hosted DeepGOPlus method",
        "packageVersion": "1.0.2",
        "dataRelease": deepgo_data_release,
        "dataUniProtRelease": deepgo_uniprot_release,
        "benchmarkT0UniProtRelease": t0_uniprot_release,
        "temporalEligibility": "formal_t0" if deepgo_t0_eligible else "post_t0_diagnostic_only",
        "resourceHashes": {
            name: sha256_file(deepgo_data / name)
            for name in (
                "model.h5",
                "terms.pkl",
                "go.obo",
                "train_data.fa",
                "train_data.dmnd",
                "metadata/last_release.json",
            )
        },
        **normalize_deepgoplus(deepgo_raw, deepgo_dir / "predictions.tsv", target_set, ontology),
    }
    finish(
        "deepgoplus_1_0_2",
        implementation,
        [deepgo_execution],
        t0_only_evidence=deepgo_t0_eligible,
    )

    unavailable = with_hash({
        "schemaVersion": "pi-lafa-temporal-pilot-unavailable-method.v1",
        "method": "prott5_embedding_similarity",
        "reference": f"LAFA_container_guide@{LAFA_GUIDE_COMMIT}/baselines/prott5_container",
        "status": "not_run",
        "reason": "The official reference requires ProtT5 embeddings plus CUDA/cuML; this Apple-silicon host has no compatible NVIDIA runtime and only limited free disk.",
        "substitutionUsed": False,
    })
    write_json(output / "prott5_embedding_similarity/status.json", unavailable)

    scopes = ["overall", "molecular_function", "biological_process", "cellular_component"]
    summary_rows = ["method\tscope\tprotein_count\tFmax\tAUPR\tIA-wFmax\tSmin\tnSmin\n"]
    summary_json: dict[str, Any] = {}
    for method, report in metric_reports.items():
        summary_json[method] = {}
        for scope in scopes:
            item = report["scopes"][scope]
            compact = {
                "proteinCount": item["proteinCount"],
                "Fmax": item["Fmax"]["f"],
                "AUPR": item["AUPR"],
                "IA-wFmax": item["IA-wFmax"]["f"],
                "Smin": item["Smin"]["smin"],
                "nSmin": item["nSmin"]["nsmin"],
            }
            summary_json[method][scope] = compact
            summary_rows.append(
                f"{method}\t{scope}\t{compact['proteinCount']}\t{compact['Fmax']:.9f}\t"
                f"{compact['AUPR']:.9f}\t{compact['IA-wFmax']:.9f}\t"
                f"{compact['Smin']:.9f}\t{compact['nSmin']:.9f}\n"
            )
    (output / "metrics_summary.tsv").write_text("".join(summary_rows), encoding="utf-8")
    formal_methods = [
        method for method, receipt in receipts.items() if receipt["t0OnlyEvidence"]
    ]
    diagnostic_methods = [
        method for method, receipt in receipts.items() if not receipt["t0OnlyEvidence"]
    ]
    summary_document = with_hash({
        "schemaVersion": "pi-lafa-temporal-random100-baseline-summary.v1",
        "suiteId": manifest["suiteId"],
        "sampleReceiptHash": json.loads((private / "sample_receipt.json").read_text(encoding="utf-8"))["canonicalHash"],
        "executedMethods": list(metric_reports),
        "formalT0Methods": formal_methods,
        "postT0DiagnosticMethods": diagnostic_methods,
        "unavailableMethods": ["prott5_embedding_similarity"],
        "metrics": summary_json,
        "claimBoundary": (
            "Preliminary fixed random-100 point estimates; full 6,905-protein evaluation remains the primary benchmark. "
            "Rows listed in postT0DiagnosticMethods are execution diagnostics and must not enter the T0 leaderboard."
        ),
    })
    write_json(output / "metrics_summary.json", summary_document)
    print(json.dumps({
        "ok": True,
        "suiteId": manifest["suiteId"],
        "executedMethods": list(metric_reports),
        "formalT0Methods": formal_methods,
        "postT0DiagnosticMethods": diagnostic_methods,
        "summary": str(output / "metrics_summary.tsv"),
    }, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    repo = Path(__file__).resolve().parents[1]
    value.add_argument("--repo", default=str(repo))
    value.add_argument("--pilot", required=True)
    value.add_argument("--benchmark-root", required=True)
    value.add_argument("--blastp", default=str(repo / ".runtime/env/bin/blastp"))
    value.add_argument("--diamond", required=True)
    value.add_argument("--mmseqs", default=shutil.which("mmseqs") or "mmseqs")
    value.add_argument("--deepgoplus-executable", required=True)
    value.add_argument("--deepgoplus-data", required=True)
    value.add_argument("--threads", type=int, default=8)
    value.add_argument("--overwrite", action="store_true")
    return value


if __name__ == "__main__":
    raise SystemExit(main(parser().parse_args()))
