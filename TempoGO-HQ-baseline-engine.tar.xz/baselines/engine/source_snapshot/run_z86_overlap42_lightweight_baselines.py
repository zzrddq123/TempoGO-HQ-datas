#!/usr/bin/env python3
"""Predict and evaluate lightweight GO baselines on the frozen Z-86 overlap-42.

The command deliberately separates prediction from evaluation.  ``predict``
does not accept a Gold/evaluator path and freezes every prediction SHA256.
``evaluate`` refuses to score any file whose bytes differ from that freeze.

The implemented methods are configurations, not all independent models:

* LAFA Naive;
* BLASTP, DIAMOND, MMseqs2, and phmmer GO transfer;
* DIAMOND DiamondScore (the same search, a different score aggregation);
* Foldseek full-length and multiscale (full-length + domain) transfer from the
  already frozen raw structure-hit bundles;
* pinned mDeepFRI sequence-CNN and structure-GCN checkpoints;
* an explicitly fixed, non-LLM max fusion;
* the already frozen stock DeepGOPlus and Agent-r7 predictions.

No prediction rule reads T1 labels.  The 42-target cohort is a previously
opened topology-selected sensitivity cohort, so the resulting numbers are an
engineering comparison rather than a prospective generalization estimate.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from build_lafa_temporal_benchmark import ROOTS, Ontology, canonical_bytes
from run_lafa_random100_baselines import (
    BaselineError,
    naive_predictions,
    prediction_stats,
    read_fasta,
    run_command,
    sha256_file,
    with_hash,
    write_json,
    write_predictions,
)


ASPECT_ORDER = ("molecular_function", "biological_process", "cellular_component")
SCOPES = ("overall", *ASPECT_ORDER)


def accession(value: str) -> str:
    fields = value.split("|")
    return fields[1] if len(fields) >= 3 else fields[0]


def load_direct_terms(
    store: Path, donors: Iterable[str], ontology: Ontology
) -> dict[str, tuple[str, ...]]:
    ordered = sorted(set(donors))
    output: dict[str, set[str]] = defaultdict(set)
    connection = sqlite3.connect(f"file:{store.resolve()}?mode=ro", uri=True)
    try:
        for offset in range(0, len(ordered), 800):
            batch = ordered[offset:offset + 800]
            if not batch:
                continue
            placeholders = ",".join("?" for _ in batch)
            statement = f"SELECT accession, go_id FROM annotations WHERE accession IN ({placeholders})"
            for donor, raw_go in connection.execute(statement, batch):
                go_id = ontology.canonical(str(raw_go))
                if go_id is None or go_id == ROOTS[ontology.namespace[go_id]]:
                    continue
                output[str(donor)].add(go_id)
    finally:
        connection.close()
    return {key: tuple(sorted(value)) for key, value in output.items()}


def tabular_transfer(
    hits_path: Path,
    annotation_store: Path,
    ontology: Ontology,
    output: Path,
    *,
    score_mode: str,
) -> dict[str, Any]:
    """Transfer donor GO terms from an eight-or-nine-column search table."""

    hits: dict[tuple[str, str], dict[str, float]] = {}
    raw_count = 0
    with hits_path.open("rt", encoding="utf-8") as handle:
        for raw in handle:
            if not raw.strip():
                continue
            row = raw.rstrip("\n").split("\t")
            if len(row) < 8:
                raise BaselineError(f"search output has fewer than eight columns: {hits_path}")
            query = accession(row[0])
            donor = accession(row[1])
            evalue = float(row[2])
            pident = float(row[4])
            bitscore = float(row[8]) if len(row) > 8 else 0.0
            raw_count += 1
            key = (query, donor)
            current = hits.get(key)
            candidate = {"evalue": evalue, "pident": pident, "bitscore": bitscore}
            if current is None or (bitscore, pident, -evalue) > (
                current["bitscore"], current["pident"], -current["evalue"]
            ):
                hits[key] = candidate

    donor_terms = load_direct_terms(annotation_store, (item[1] for item in hits), ontology)
    query_max_bitscore: dict[str, float] = defaultdict(float)
    for (query, _), item in hits.items():
        query_max_bitscore[query] = max(query_max_bitscore[query], item["bitscore"])

    scores: dict[tuple[str, str], float] = {}
    annotated_queries: set[str] = set()
    for (query, donor), item in hits.items():
        terms = donor_terms.get(donor, ())
        if terms:
            annotated_queries.add(query)
        if score_mode == "identity":
            score = item["pident"] / 100.0
        elif score_mode == "diamond_score":
            denominator = query_max_bitscore[query]
            score = item["bitscore"] / denominator if denominator > 0 else 0.0
        else:
            raise BaselineError(f"unknown tabular score mode: {score_mode}")
        score = min(1.0, max(0.0, score))
        for go_id in terms:
            key = (query, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((query, go_id, score) for (query, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": (
            "per-term maximum local-alignment identity"
            if score_mode == "identity"
            else "per-term maximum bitscore divided by the query top bitscore"
        ),
        "scoreMode": score_mode,
        "rawHitCount": raw_count,
        "deduplicatedQueryDonorCount": len(hits),
        "uniqueDonorCount": len({item[1] for item in hits}),
        "annotatedDonorCount": sum(bool(donor_terms.get(item)) for item in donor_terms),
        "queriesWithAnnotatedHits": len(annotated_queries),
    }


def phmmer_transfer(
    table: Path, annotation_store: Path, ontology: Ontology, output: Path, max_hits: int = 500
) -> dict[str, Any]:
    """Transfer terms from phmmer full-sequence scores, normalized per query."""

    per_query: dict[str, list[tuple[str, float, float]]] = defaultdict(list)
    raw_count = 0
    with table.open("rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            if not raw.strip() or raw.startswith("#"):
                continue
            row = raw.split()
            if len(row) < 6:
                raise BaselineError(f"invalid phmmer --tblout row: {raw[:200]}")
            donor = accession(row[0])
            query = accession(row[2])
            evalue = float(row[4])
            bitscore = float(row[5])
            per_query[query].append((donor, bitscore, evalue))
            raw_count += 1

    selected: dict[tuple[str, str], tuple[float, float]] = {}
    for query, rows in per_query.items():
        rows.sort(key=lambda item: (-item[1], item[2], item[0]))
        for donor, bitscore, evalue in rows[:max_hits]:
            key = (query, donor)
            previous = selected.get(key)
            if previous is None or (bitscore, -evalue) > (previous[0], -previous[1]):
                selected[key] = (bitscore, evalue)
    donor_terms = load_direct_terms(annotation_store, (item[1] for item in selected), ontology)
    maxima: dict[str, float] = defaultdict(float)
    for (query, _), (bitscore, _) in selected.items():
        maxima[query] = max(maxima[query], bitscore)
    scores: dict[tuple[str, str], float] = {}
    annotated_queries: set[str] = set()
    for (query, donor), (bitscore, _) in selected.items():
        terms = donor_terms.get(donor, ())
        if terms:
            annotated_queries.add(query)
        score = max(0.0, bitscore) / maxima[query] if maxima[query] > 0 else 0.0
        for go_id in terms:
            key = (query, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((query, go_id, score) for (query, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": "phmmer top-N donor transfer with per-query normalized full-sequence bitscore",
        "maxHitsPerQuery": max_hits,
        "rawHitCount": raw_count,
        "deduplicatedQueryDonorCount": len(selected),
        "queriesWithAnnotatedHits": len(annotated_queries),
    }


def foldseek_transfer(
    evidence_root: Path,
    targets: list[str],
    annotation_store: Path,
    ontology: Ontology,
    output: Path,
    *,
    multiscale: bool,
) -> dict[str, Any]:
    """Score frozen PDB100 hits without using Agent-retained GO candidates."""

    rows: list[tuple[str, str, float, str]] = []
    scopes: dict[str, int] = defaultdict(int)
    for target in targets:
        path = evidence_root / target / "evidence/blind_evidence_bundle.json"
        bundle = json.loads(path.read_text(encoding="utf-8"))
        for hit in bundle.get("structure_hits", []):
            scope = str(hit.get("scope", ""))
            if not multiscale and scope != "full_length":
                continue
            donor = hit.get("annotation_accession")
            if not isinstance(donor, str) or not donor or hit.get("query_like") is True:
                continue
            alignment_tm = float(hit.get("alignment_tm_score") or 0.0)
            query_coverage = float(hit.get("query_coverage") or 0.0)
            # Coverage-weighted TM score is fixed before evaluation.  Domain
            # coverage is relative to the domain query, so this rule supports
            # both full-chain and domain hits without a Gold-tuned coefficient.
            score = min(1.0, max(0.0, alignment_tm * query_coverage))
            if score > 0:
                rows.append((target, donor, score, scope))
                scopes[scope] += 1
    donor_terms = load_direct_terms(annotation_store, (item[1] for item in rows), ontology)
    scores: dict[tuple[str, str], float] = {}
    annotated_queries: set[str] = set()
    for query, donor, score, _ in rows:
        terms = donor_terms.get(donor, ())
        if terms:
            annotated_queries.add(query)
        for go_id in terms:
            key = (query, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((query, go_id, score) for (query, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": "coverage-weighted Foldseek PDB100 250101 GO transfer",
        "configuration": "full_plus_domain" if multiscale else "full_length_only",
        "termScore": "max(alignment_tm_score * query_coverage)",
        "rawFrozenHitCount": len(rows),
        "hitCountByScope": dict(sorted(scopes.items())),
        "queriesWithAnnotatedHits": len(annotated_queries),
        "sourceBoundary": (
            "Reuses pre-Gold frozen raw structure hits from Agent evidence bundles; "
            "it does not reuse the Agent candidate ranking or final GO decisions."
        ),
    }


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def binary_binding(value: str) -> dict[str, Any]:
    path = Path(value).resolve(strict=True)
    return {
        "path": str(path),
        "sizeBytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def canonical_fasta_hash(sequence: str) -> str:
    text = ">anonymous_query\n" + "\n".join(
        sequence[offset:offset + 80] for offset in range(0, len(sequence), 80)
    ) + "\n"
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def deepfri_method(
    repo: Path, architecture: str, threshold: float, adapter_config: Path
) -> tuple[dict[str, Any], dict[str, Any], Path, Path, str]:
    if architecture not in {"cnn", "gcn"}:
        raise BaselineError(f"invalid mDeepFRI architecture: {architecture}")
    lock_path = repo / f"bootstrap/mdeepfri-{'cnn' if architecture == 'cnn' else 'gcn'}-v1.lock.json"
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    data = Path(os.environ.get("MDEEPFRI_MODEL_DIR", str(repo / ".runtime/v0005-mdeepfri-data/mdeepfri-v1.0"))).expanduser().resolve()
    runner = repo / lock["adapter"]["sourcePath"]
    source_config = data / lock["model"]["config"]["name"]
    by_aspect: dict[str, dict[str, Any]] = {}
    for aspect in ASPECT_ORDER:
        items = [item for item in lock["model"]["files"] if item["aspect"] == aspect]
        by_aspect[aspect] = {
            "aspect": aspect,
            "paramsPath": str(data / next(item["name"] for item in items if item["kind"] == "model_params")),
            "onnxPath": str(data / next(item["name"] for item in items if item["kind"] == "onnx")),
            "paramsSha256": next(item["sha256"] for item in items if item["kind"] == "model_params"),
            "onnxSha256": next(item["sha256"] for item in items if item["kind"] == "onnx"),
        }
    for item in by_aspect.values():
        if sha256_file(Path(item["paramsPath"])) != item["paramsSha256"]:
            raise BaselineError("mDeepFRI parameter hash mismatch")
        if sha256_file(Path(item["onnxPath"])) != item["onnxSha256"]:
            raise BaselineError("mDeepFRI ONNX hash mismatch")
    if sha256_file(runner) != lock["adapter"]["runnerSha256"]:
        raise BaselineError("mDeepFRI runner hash mismatch")
    if sha256_file(source_config) != lock["model"]["config"]["sha256"]:
        raise BaselineError("mDeepFRI config hash mismatch")

    # The upstream model_config uses nested {gcn, models} objects, whereas the
    # repository-owned fail-closed runners deliberately accept a smaller
    # adapter schema.  Derive that schema deterministically while preserving
    # the source-config hash and all six locked model hashes in the receipt.
    adapter_document = {
        "version": "mdeepfri-1.0-adapter",
        "cnn": {
            mode: Path(by_aspect[aspect]["onnxPath"]).name
            for aspect, mode in zip(ASPECT_ORDER, ("mf", "bp", "cc"))
            if architecture == "cnn"
        },
        "gcn": {
            mode: Path(by_aspect[aspect]["onnxPath"]).name
            for aspect, mode in zip(ASPECT_ORDER, ("mf", "bp", "cc"))
            if architecture == "gcn"
        },
    }
    adapter_config.parent.mkdir(parents=True, exist_ok=True)
    adapter_config.write_bytes(
        json.dumps(adapter_document, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        + b"\n"
    )
    adapter_config_sha256 = sha256_file(adapter_config)

    model_files = [
        {
            "aspect": aspect,
            "paramsSha256": by_aspect[aspect]["paramsSha256"],
            "onnxSha256": by_aspect[aspect]["onnxSha256"],
        }
        for aspect in ASPECT_ORDER
    ]
    schema = f"pi-mdeepfri-{architecture}-model-set.v1"
    model_hash = canonical_hash({
        "schemaVersion": schema,
        "modelConfigSha256": adapter_config_sha256,
        "modelFiles": model_files,
    })
    content: dict[str, Any] = {
        "provider": "mDeepFRI",
        "sourceType": f"mdeepfri_{architecture}",
        "annotationEvidenceCode": "MODEL",
        "architecture": architecture,
    }
    if architecture == "gcn":
        content.update({"structurePolicy": "single_chain_exact_ca_v1", "contactThresholdAngstrom": 10})
    content.update({
        "toolName": f"deepfri-{architecture}-onnx-adapter",
        "packageName": "onnxruntime",
        "packageVersion": lock["adapter"]["runtimeVersion"],
        "runnerSha256": lock["adapter"]["runnerSha256"],
        "modelSha256": model_hash,
        "modelConfigSha256": adapter_config_sha256,
        "modelFiles": model_files,
        "exportMinimumScore": threshold,
    })
    method = {**content, "methodHash": canonical_hash(content)}
    artifacts = {
        "modelConfigPath": str(adapter_config),
        "modelFiles": [
            {
                "aspect": aspect,
                "paramsPath": by_aspect[aspect]["paramsPath"],
                "onnxPath": by_aspect[aspect]["onnxPath"],
            }
            for aspect in ASPECT_ORDER
        ],
    }
    python_bin = repo / f".runtime/predictors/mdeepfri-{architecture}-v1/bin/python"
    return method, artifacts, runner, python_bin, sha256_file(source_config)


def run_mdeepfri(
    repo: Path,
    architecture: str,
    targets: dict[str, str],
    structures: Path,
    ontology: Ontology,
    output: Path,
    threshold: float = 0.01,
) -> dict[str, Any]:
    work = output.parent / "work"
    work.mkdir(parents=True, exist_ok=True)
    method, artifacts, runner, python_bin, source_config_sha256 = deepfri_method(
        repo, architecture, threshold, work / "adapter_config.json"
    )
    reverse: dict[str, str] = {}
    cases: list[dict[str, Any]] = []
    for index, (target, sequence) in enumerate(targets.items(), start=1):
        fasta_hash = canonical_fasta_hash(sequence)
        case_id = f"CASE_{index:03d}_{fasta_hash[:8].upper()}"
        reverse[case_id] = target
        case: dict[str, Any] = {
            "caseId": case_id,
            "sequenceSha256": fasta_hash,
            "sequence": sequence,
        }
        if architecture == "gcn":
            structure = structures / f"{target}.pdb"
            case.update({"structureSha256": sha256_file(structure), "structurePath": str(structure)})
        cases.append(case)
    request = {
        "schemaVersion": (
            "pi-external-go-predictor-run-request.v1"
            if architecture == "cnn"
            else "pi-external-go-gcn-run-request.v1"
        ),
        "method": method,
        "artifacts": artifacts,
        "cases": cases,
    }
    request_path = work / "request.json"
    response_path = work / "response.json"
    request_path.write_bytes(json.dumps(request, ensure_ascii=False, indent=2).encode("utf-8") + b"\n")
    started = time.monotonic()
    result = subprocess.run(
        [str(python_bin), str(runner)],
        input=request_path.read_bytes(),
        capture_output=True,
        timeout=3600,
        check=False,
    )
    if result.returncode != 0:
        raise BaselineError(
            f"mDeepFRI {architecture} failed ({result.returncode}): "
            + result.stderr.decode("utf-8", errors="replace")[-4000:]
        )
    response_path.write_bytes(result.stdout)
    response = json.loads(result.stdout)
    scores: dict[tuple[str, str], float] = {}
    for item in response["cases"]:
        target = reverse[item["caseId"]]
        for prediction in item["predictions"]:
            go_id = ontology.canonical(prediction["goId"])
            if go_id is None or go_id == ROOTS[ontology.namespace[go_id]]:
                continue
            score = float(prediction["score"])
            key = (target, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": f"hash-bound mDeepFRI {architecture.upper()} fixed checkpoint",
        "architecture": architecture,
        "checkpointClaimBoundary": (
            "Temporal use is pre-T0, but sequence-level training overlap was not audited; "
            "this is not an unseen-protein claim."
        ),
        "method": method,
        "upstreamSourceConfigSha256": source_config_sha256,
        "requestSha256": sha256_file(request_path),
        "responseSha256": sha256_file(response_path),
        "durationSeconds": round(time.monotonic() - started, 3),
        "predictionRows": len(scores),
    }


def load_prediction_scores(path: Path, allowed: set[str]) -> dict[tuple[str, str], float]:
    output: dict[tuple[str, str], float] = {}
    with path.open("rt", encoding="utf-8") as handle:
        header = next(handle, "").rstrip("\n")
        if header != "target_id\tgo_id\tscore":
            raise BaselineError(f"invalid prediction header: {path}")
        for raw in handle:
            target, go_id, raw_score = raw.rstrip("\n").split("\t")
            if target not in allowed:
                continue
            score = float(raw_score)
            key = (target, go_id)
            output[key] = max(output.get(key, 0.0), score)
    return output


def copy_frozen_predictions(source: Path, output: Path, allowed: set[str]) -> dict[str, Any]:
    scores = load_prediction_scores(source, allowed)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": "byte-normalized subset of an already frozen prediction surface",
        "source": str(source),
        "sourceSha256": sha256_file(source),
        "rows": len(scores),
    }


def fixed_max_fusion(
    inputs: dict[str, Path], allowed: set[str], output: Path
) -> dict[str, Any]:
    combined: dict[tuple[str, str], float] = {}
    input_hashes: dict[str, str] = {}
    for name, path in inputs.items():
        input_hashes[name] = sha256_file(path)
        for key, score in load_prediction_scores(path, allowed).items():
            combined[key] = max(combined.get(key, 0.0), score)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(combined.items())),
    )
    return {
        "algorithm": "fixed per-term maximum across frozen input channels",
        "goldTuned": False,
        "inputPredictionHashes": input_hashes,
        "note": "Static non-LLM control; no learned or development-set calibrated weights.",
    }


def method_receipt(
    output: Path,
    method: str,
    implementation: dict[str, Any],
    executions: list[dict[str, Any]],
    eligibility: str,
) -> dict[str, Any]:
    document = with_hash({
        "schemaVersion": "pi-z86-overlap42-baseline-run.v1",
        "cohort": "z86-frontier-complete-overlap42",
        "method": method,
        "eligibility": eligibility,
        "predictionOnly": True,
        "implementation": implementation,
        "executions": executions,
        "prediction": prediction_stats(output),
    })
    write_json(output.parent / "run_receipt.json", document)
    return document


def predict(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    audit = Path(args.audit).resolve()
    t0_root = Path(args.t0_root).resolve()
    output = Path(args.output).resolve()
    if output.exists() and any(output.iterdir()):
        raise BaselineError(f"prediction output already exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    targets = read_fasta(audit / "targets.fasta")
    target_ids = [item for item in (audit / "target_ids.txt").read_text().splitlines() if item]
    if target_ids != list(targets):
        raise BaselineError("target ID order and FASTA order differ")
    target_set = set(target_ids)
    ontology = Ontology(Path(args.ontology).resolve())
    annotation_store = t0_root / "resources/t0_annotations_v3.sqlite3"
    t0 = t0_root / "sources/t0/Sep_2025"
    receipts: dict[str, Any] = {}

    def finish(
        name: str,
        implementation: dict[str, Any],
        executions: list[dict[str, Any]] | None = None,
        eligibility: str = "formal_t0",
    ) -> None:
        receipts[name] = method_receipt(
            output / name / "predictions.tsv",
            name,
            implementation,
            executions or [],
            eligibility,
        )

    name = "lafa_naive"
    finish(name, naive_predictions(
        target_ids,
        t0 / "train_terms_propagated.tsv",
        ontology,
        output / name / "predictions.tsv",
    ))

    # Existing comparison surfaces are copied before any evaluation is opened.
    name = "deepgoplus_1_0_2_data_1_0_25"
    finish(name, copy_frozen_predictions(
        audit / "deepgoplus/predictions.tsv", output / name / "predictions.tsv", target_set
    ), eligibility="fixed_checkpoint_temporal_not_training_clean")
    name = "agent_r7"
    finish(name, copy_frozen_predictions(
        audit / "agent_r7_final_predictions.tsv", output / name / "predictions.tsv", target_set
    ), eligibility="opened_development_agent_comparison")

    searches: list[tuple[str, list[str], Path, str]] = []
    blast_hits = output / "blastp_identity/work/hits.tsv"
    blast_hits.parent.mkdir(parents=True, exist_ok=True)
    searches.append((
        "blastp_identity",
        [
            args.blastp, "-query", str(audit / "targets.fasta"), "-db",
            str(t0_root / "resources/blast/lafa_sep2025"), "-out", str(blast_hits),
            "-outfmt", "6 qseqid sseqid evalue length pident nident qlen slen bitscore",
            "-evalue", "10", "-max_target_seqs", "500", "-num_threads", str(args.threads),
        ],
        blast_hits,
        "identity",
    ))

    diamond_work = output / "diamond_identity/work"
    diamond_work.mkdir(parents=True, exist_ok=True)
    diamond_db = diamond_work / "lafa_sep2025"
    diamond_make = run_command([
        args.diamond, "makedb", "--in", str(t0 / "train_sequences.fasta"), "--db", str(diamond_db)
    ], cwd=repo, timeout=1800)
    diamond_hits = diamond_work / "hits.tsv"
    diamond_search = [
        args.diamond, "blastp", "--query", str(audit / "targets.fasta"), "--db", str(diamond_db),
        "--out", str(diamond_hits), "--outfmt", "6", "qseqid", "sseqid", "evalue", "length",
        "pident", "nident", "qlen", "slen", "bitscore", "--evalue", "10",
        "--max-target-seqs", "500", "--threads", str(args.threads),
    ]
    diamond_execution = run_command(diamond_search, cwd=repo, timeout=3600)
    diamond_common = {
        "binary": binary_binding(args.diamond),
        "databaseSha256": sha256_file(Path(str(diamond_db) + ".dmnd")),
        "searchDatabase": "LAFA Sep-2025 T0 donors",
    }
    for name, mode in (("diamond_identity", "identity"), ("diamond_score", "diamond_score")):
        finish(name, {
            **diamond_common,
            **tabular_transfer(
                diamond_hits, annotation_store, ontology, output / name / "predictions.tsv", score_mode=mode
            ),
            "configurationBoundary": "same DIAMOND search; score aggregation differs",
        }, [diamond_make, diamond_execution])

    mmseqs_hits = output / "mmseqs2_identity/work/hits.tsv"
    mmseqs_hits.parent.mkdir(parents=True, exist_ok=True)
    mmseqs_command = [
        args.mmseqs, "easy-search", str(audit / "targets.fasta"), str(t0 / "train_sequences.fasta"),
        str(mmseqs_hits), str(mmseqs_hits.parent / "tmp"), "--format-output",
        "query,target,evalue,alnlen,pident,nident,qlen,tlen,bits", "--max-seqs", "500",
        "--threads", str(args.threads),
    ]
    searches.append(("mmseqs2_identity", mmseqs_command, mmseqs_hits, "identity"))

    for name, command, hit_path, mode in searches:
        execution = run_command(command, cwd=repo, timeout=3600)
        finish(name, {
            "binary": binary_binding(command[0]),
            "searchDatabase": "LAFA Sep-2025 T0 donors",
            **tabular_transfer(
                hit_path, annotation_store, ontology, output / name / "predictions.tsv", score_mode=mode
            ),
        }, [execution])

    name = "phmmer_score"
    phmmer_table = output / name / "work/hits.tbl"
    phmmer_table.parent.mkdir(parents=True, exist_ok=True)
    phmmer_execution = run_command([
        args.phmmer, "--tblout", str(phmmer_table), "--noali", "--cpu", str(args.threads),
        "-E", "10", str(audit / "targets.fasta"), str(t0 / "train_sequences.fasta"),
    ], cwd=repo, timeout=7200)
    finish(name, {
        "binary": binary_binding(args.phmmer),
        "searchDatabase": "LAFA Sep-2025 T0 donors",
        **phmmer_transfer(phmmer_table, annotation_store, ontology, output / name / "predictions.tsv"),
    }, [phmmer_execution])

    for name, multiscale in (("foldseek_full", False), ("foldseek_multiscale", True)):
        finish(name, foldseek_transfer(
            audit / "agent_r7_runs",
            target_ids,
            annotation_store,
            ontology,
            output / name / "predictions.tsv",
            multiscale=multiscale,
        ))

    for name, architecture in (("mdeepfri_cnn", "cnn"), ("mdeepfri_gcn", "gcn")):
        finish(name, run_mdeepfri(
            repo,
            architecture,
            targets,
            audit / "structures_all42",
            ontology,
            output / name / "predictions.tsv",
        ), eligibility="fixed_checkpoint_temporal_not_training_clean")

    name = "fixed_fusion_max"
    fusion_inputs = {
        item: output / item / "predictions.tsv"
        for item in (
            "deepgoplus_1_0_2_data_1_0_25",
            "blastp_identity",
            "phmmer_score",
            "foldseek_multiscale",
        )
    }
    finish(name, fixed_max_fusion(fusion_inputs, target_set, output / name / "predictions.tsv"),
           eligibility="fixed_checkpoint_plus_formal_t0_static_control")

    freeze = with_hash({
        "schemaVersion": "pi-z86-overlap42-prediction-freeze.v1",
        "cohort": "z86-frontier-complete-overlap42",
        "targetCount": len(target_ids),
        "runnerSha256": sha256_file(Path(__file__).resolve()),
        "resourceBindings": {
            "publicOntologySha256": sha256_file(Path(args.ontology).resolve()),
            "t0TrainSequencesSha256": sha256_file(t0 / "train_sequences.fasta"),
            "t0PropagatedTermsSha256": sha256_file(t0 / "train_terms_propagated.tsv"),
            "t0AnnotationManifestSha256": sha256_file(t0_root / "resources/t0_annotations_v3.manifest.json"),
            "t0BlastManifestSha256": sha256_file(t0_root / "resources/t0_blast.manifest.json"),
            "structureReceiptSha256": sha256_file(audit / "structure_receipt_all42.json"),
        },
        "targetIdsSha256": sha256_file(audit / "target_ids.txt"),
        "targetFastaSha256": sha256_file(audit / "targets.fasta"),
        "methods": {
            name: {
                "predictionSha256": receipt["prediction"]["sha256"],
                "predictionRows": receipt["prediction"]["rowCount"],
                "predictedTargetCount": receipt["prediction"]["predictedTargetCount"],
                "receiptHash": receipt["canonicalHash"],
                "eligibility": receipt["eligibility"],
            }
            for name, receipt in sorted(receipts.items())
        },
        "claimBoundary": (
            "Prediction bytes were frozen before this script accepted any Gold/evaluator path. "
            "The overlap-42 cohort itself was previously selected with GO topology and is not prospective."
        ),
    })
    write_json(output / "prediction_freeze.json", freeze)
    print(json.dumps({
        "ok": True,
        "stage": "predict",
        "methodCount": len(receipts),
        "freezeHash": freeze["canonicalHash"],
        "output": str(output),
    }, indent=2))
    return 0


def compact_metrics(report: dict[str, Any]) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for scope in SCOPES:
        item = report["scopes"][scope]
        output[scope] = {
            "proteinCount": item["proteinCount"],
            "Fmax": item["Fmax"]["f"],
            "AUPR": item["AUPR"],
            "IA-wFmax": item["IA-wFmax"]["f"],
            "Smin": item["Smin"]["smin"],
            "nSmin": item["nSmin"]["nsmin"],
        }
    return output


def evaluate(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    benchmark = Path(args.benchmark).resolve()
    audit = Path(args.audit).resolve()
    output = Path(args.output).resolve()
    freeze = json.loads((output / "prediction_freeze.json").read_text(encoding="utf-8"))
    expected_hash = freeze.pop("canonicalHash")
    if canonical_hash(freeze) != expected_hash:
        raise BaselineError("prediction freeze canonical hash mismatch")
    if sha256_file(Path(__file__).resolve()) != freeze["runnerSha256"]:
        raise BaselineError("baseline runner changed after prediction freeze")
    metrics: dict[str, Any] = {}
    executions: dict[str, Any] = {}
    for method, item in sorted(freeze["methods"].items()):
        prediction = output / method / "predictions.tsv"
        if sha256_file(prediction) != item["predictionSha256"]:
            raise BaselineError(f"prediction changed after freeze: {method}")
        report = output / method / "metrics.json"
        execution = run_command([
            sys.executable,
            str(repo / "scripts/evaluate_lafa_temporal_benchmark.py"),
            "--benchmark", str(benchmark),
            "--predictions", str(prediction),
            "--target-ids", str(audit / "target_ids.txt"),
            "--output", str(report),
        ], cwd=repo, timeout=3600)
        executions[method] = execution
        metrics[method] = compact_metrics(json.loads(report.read_text(encoding="utf-8")))

    header = ["method"]
    for scope in SCOPES:
        header.extend(f"{scope}_{metric}" for metric in ("Fmax", "AUPR", "IA-wFmax", "Smin", "nSmin"))
    lines = ["\t".join(header) + "\n"]
    for method, scopes in metrics.items():
        row = [method]
        for scope in SCOPES:
            row.extend(f"{scopes[scope][metric]:.9f}" for metric in (
                "Fmax", "AUPR", "IA-wFmax", "Smin", "nSmin"
            ))
        lines.append("\t".join(row) + "\n")
    (output / "metrics_summary.tsv").write_text("".join(lines), encoding="utf-8")
    summary = with_hash({
        "schemaVersion": "pi-z86-overlap42-lightweight-baseline-summary.v1",
        "predictionFreezeHash": expected_hash,
        "targetCount": freeze["targetCount"],
        "methods": freeze["methods"],
        "metrics": metrics,
        "evaluationExecutions": executions,
        "claimBoundary": (
            "Same 42-target mask and current Z-86 v3 evaluator for every row. Search engines and "
            "Foldseek lanes are configurations, not independent learned models. DeepGOPlus, mDeepFRI, "
            "and Agent rows are not training-clean. The cohort is an opened topology-selected sensitivity set."
        ),
    })
    write_json(output / "metrics_summary.json", summary)
    print(json.dumps({
        "ok": True,
        "stage": "evaluate",
        "methodCount": len(metrics),
        "summaryHash": summary["canonicalHash"],
        "summary": str(output / "metrics_summary.tsv"),
    }, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    repo = Path(__file__).resolve().parents[1]
    default_audit = repo / "benchmark_runs/z86-frontier-complete-overlap42-r7-audit"
    value = argparse.ArgumentParser(description=__doc__)
    stages = value.add_subparsers(dest="stage", required=True)

    def common(stage: argparse.ArgumentParser) -> None:
        stage.add_argument("--repo", default=str(repo))
        stage.add_argument("--audit", default=str(default_audit))
        stage.add_argument(
            "--output", default=str(repo / "benchmark_runs/z86-frontier-complete-overlap42-baselines-v1")
        )

    predict_parser = stages.add_parser("predict", help="generate and hash-freeze predictions; no Gold path")
    common(predict_parser)
    predict_parser.add_argument(
        "--ontology", required=True,
        help="public scoring ontology only; no evaluator-private path is accepted",
    )
    predict_parser.add_argument(
        "--t0-root", required=True
    )
    predict_parser.add_argument("--threads", type=int, choices=(1, 2), default=2)
    predict_parser.add_argument("--blastp", default=str(repo / ".runtime/env/bin/blastp"))
    predict_parser.add_argument("--diamond", required=True)
    predict_parser.add_argument("--mmseqs", default=shutil.which("mmseqs") or "mmseqs")
    predict_parser.add_argument(
        "--phmmer", default=str(repo / ".runtime/predictors/hmmer-baseline-v1/bin/phmmer")
    )

    evaluate_parser = stages.add_parser("evaluate", help="score hash-frozen predictions")
    common(evaluate_parser)
    evaluate_parser.add_argument("--benchmark", required=True)
    return value


if __name__ == "__main__":
    arguments = parser().parse_args()
    raise SystemExit(predict(arguments) if arguments.stage == "predict" else evaluate(arguments))
