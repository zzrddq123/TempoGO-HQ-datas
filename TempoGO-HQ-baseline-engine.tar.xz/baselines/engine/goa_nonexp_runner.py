#!/usr/bin/env python3
"""Historical GOA Non-exp T0 same-accession diagnostic runner."""
from __future__ import annotations
import argparse,csv,gzip,hashlib,json
from pathlib import Path
CODES={"ISS","ISO","ISA","ISM","IGC","RCA","IBA","IBD","IKR","IRD","IEA","ND","NAS"}
ROOTS={"GO:0003674","GO:0008150","GO:0005575"}
def sha(p):
 h=hashlib.sha256()
 with p.open("rb") as f:
  for b in iter(lambda:f.read(1024*1024),b""):h.update(b)
 return h.hexdigest()
def ontology(path):
 valid=set();alt={};current=None;obsolete=False;alts=[]
 def emit():
  if current and not obsolete:
   valid.add(current)
   for value in alts:alt[value]=current
 with path.open() as f:
  for raw in f:
   line=raw.rstrip("\n")
   if line=="[Term]":emit();current=None;obsolete=False;alts=[]
   elif line.startswith("id: GO:"):current=line.split()[1]
   elif line.startswith("alt_id: GO:"):alts.append(line.split()[1])
   elif line=="is_obsolete: true":obsolete=True
  emit()
 return valid,alt
def run(identity_path,gaf_path,ontology_path,output):
 valid,alt=ontology(ontology_path);mapping={r["accession"]:r["target_id"] for r in csv.DictReader(identity_path.open(),delimiter="\t")};scores=set();stats={"gafRows":0,"selectedRows":0,"notExcludedRows":0,"unknownOrRootDroppedRows":0}
 opener=gzip.open if gaf_path.suffix==".gz" else open
 with opener(gaf_path,"rt") as f:
  for raw in f:
   if not raw or raw.startswith("!"):continue
   stats["gafRows"]+=1;cols=raw.rstrip("\n").split("\t")
   if len(cols)<9 or cols[0]!="UniProtKB" or cols[1] not in mapping or cols[6] not in CODES:continue
   if "NOT" in set(filter(None,cols[3].split("|"))):stats["notExcludedRows"]+=1;continue
   go=alt.get(cols[4],cols[4])
   if go not in valid or go in ROOTS:stats["unknownOrRootDroppedRows"]+=1;continue
   scores.add((mapping[cols[1]],go));stats["selectedRows"]+=1
 output.parent.mkdir(parents=True,exist_ok=True)
 with output.open("w") as h:
  h.write("target_id\tgo_id\tscore\n")
  for target,go in sorted(scores):h.write(f"{target}\t{go}\t1.0\n")
 receipt={"schemaVersion":"functionbench-goa-nonexp-same-accession-run.v1","methodId":"goa_nonexp_t0_same_accession_oracle","targetCount":len(mapping),"predictedTargetCount":len({x[0] for x in scores}),"predictionRows":len(scores),"predictionSha256":sha(output),"t0GoaSha256":sha(gaf_path),"identityMapSha256":sha(identity_path),"ontologySha256":sha(ontology_path),"selectedEvidenceCodes":sorted(CODES),"score":1.0,"identityPolicy":"evaluator_private_same_accession","claimBoundary":"T0 same-accession database-availability diagnostic; not equal-input anonymous prediction.","scan":stats}
 body=json.dumps(receipt,sort_keys=True,separators=(",",":")).encode();receipt["canonicalHash"]=hashlib.sha256(body).hexdigest();rp=output.parent/"goa_nonexp_receipt.json";rp.write_text(json.dumps(receipt,indent=2)+"\n");print(json.dumps({"ok":True,"prediction":str(output),"receipt":str(rp),"rows":len(scores),"predictedTargets":receipt["predictedTargetCount"]},indent=2))
def main():
 p=argparse.ArgumentParser();p.add_argument("--identity-map",required=True);p.add_argument("--gaf",required=True);p.add_argument("--ontology",required=True);p.add_argument("--output",required=True);a=p.parse_args();run(Path(a.identity_map),Path(a.gaf),Path(a.ontology),Path(a.output))
if __name__=="__main__":main()
