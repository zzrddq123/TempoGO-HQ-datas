#!/usr/bin/env python3
"""Run and score the 12 non-agent Z-86 baselines on groups 1--3.

The workflow has three deliberately separated stages:

* ``prepare-foldseek`` validates/reuses or computes structure domains, runs the
  frozen local PDB100 search, bridges PDB hits to the frozen T0 donor database,
  and hash-freezes the two Foldseek prediction surfaces;
* ``predict`` runs the remaining T0/fixed-checkpoint baselines without accepting
  any evaluator-private path, copies the Foldseek freeze, and freezes all 12
  prediction files;
* ``evaluate`` verifies the prediction freeze and scores the exact same bytes on
  each of the three 72-protein benchmark masks.

Predictions are generated once for the 216-target union and only then subset by
group.  This is equivalent to three independent runs because every method is
target-local, while avoiding repeated model/search initialization.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

SUITE_ROOT = Path(__file__).resolve().parents[2]
REPO_ROOT = SUITE_ROOT
sys.path.insert(0, str(REPO_ROOT / "scripts"))
sys.path.insert(0, str(REPO_ROOT / "python"))
sys.path.insert(0, str(Path(__file__).resolve().parent / "source_snapshot"))

from build_lafa_temporal_benchmark import ROOTS, Ontology, canonical_bytes
from evidence_pipeline import (
    map_pdb_hits_to_t0_uniprot,
    parse_domain_file,
    run_foldseek_scope,
    run_segmenters,
)
from run_lafa_random100_baselines import (
    BaselineError,
    naive_predictions,
    prediction_stats,
    read_fasta,
    run_command,
    sha256_file,
    with_hash,
    write_json,
    write_predictions,
)
from run_z86_overlap42_lightweight_baselines import (
    ASPECT_ORDER,
    SCOPES,
    binary_binding,
    canonical_fasta_hash,
    compact_metrics,
    copy_frozen_predictions,
    deepfri_method,
    fixed_max_fusion,
    load_direct_terms,
    phmmer_transfer,
    tabular_transfer,
)


METHODS = (
    "lafa_naive",
    "blastp_identity",
    "diamond_identity",
    "diamond_score",
    "mmseqs2_identity",
    "phmmer_score",
    "foldseek_full",
    "foldseek_multiscale",
    "mdeepfri_cnn",
    "mdeepfri_gcn",
    "deepgoplus_1_0_2_data_1_0_25",
    "fixed_fusion_max",
)


def method_receipt(
    output: Path,
    method: str,
    implementation: dict[str, Any],
    executions: list[dict[str, Any]],
    eligibility: str,
) -> dict[str, Any]:
    """Write a provenance receipt for this 216-target cohort."""
    document = with_hash({
        "schemaVersion": "pi-registered-baseline-run.v1",
        "cohort": "registered-query-cohort",
        "method": method,
        "eligibility": eligibility,
        "predictionOnly": True,
        "implementation": implementation,
        "executions": executions,
        "prediction": prediction_stats(output),
    })
    write_json(output.parent / "run_receipt.json", document)
    return document
DISPLAY_NAMES = {
    "lafa_naive": "LAFA Naive",
    "blastp_identity": "BLASTP max-identity",
    "diamond_identity": "DIAMOND max-identity",
    "diamond_score": "DIAMOND DiamondScore",
    "mmseqs2_identity": "MMseqs2 max-identity",
    "phmmer_score": "phmmer GO transfer",
    "foldseek_full": "Foldseek full-length",
    "foldseek_multiscale": "Foldseek multiscale",
    "mdeepfri_cnn": "mDeepFRI CNN",
    "mdeepfri_gcn": "mDeepFRI GCN",
    "deepgoplus_1_0_2_data_1_0_25": "DeepGOPlus 1.0.2 (data 1.0.25)",
    "fixed_fusion_max": "FixedFusion-Max",
}
TABLE_METRICS = (
    ("overall", "Fmax"),
    ("overall", "AUPR"),
    ("overall", "IA-wFmax"),
    ("overall", "nSmin"),
    ("molecular_function", "Fmax"),
    ("molecular_function", "AUPR"),
    ("molecular_function", "IA-wFmax"),
    ("molecular_function", "Smin"),
    ("biological_process", "Fmax"),
    ("biological_process", "AUPR"),
    ("biological_process", "IA-wFmax"),
    ("biological_process", "Smin"),
    ("cellular_component", "Fmax"),
    ("cellular_component", "AUPR"),
    ("cellular_component", "IA-wFmax"),
    ("cellular_component", "Smin"),
)


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def parse_env_file(path: Path) -> dict[str, str]:
    output: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        output[key.strip()] = value.strip()
    return output


def validate_targets(audit: Path) -> tuple[dict[str, str], list[str]]:
    targets = read_fasta(audit / "targets.fasta")
    target_ids = [item for item in (audit / "target_ids.txt").read_text().splitlines() if item]
    if target_ids != list(targets) or not target_ids or len(set(target_ids)) != len(target_ids):
        raise BaselineError("target ID/FASTA contract is empty, duplicate, or order-inconsistent")
    structures = audit / "structures_all216"
    missing = [target for target in target_ids if not (structures / f"{target}.pdb").is_file()]
    if missing:
        raise BaselineError(f"missing {len(missing)} admitted structures")
    return targets, target_ids


def external_domain_roots(repo: Path, target_ids: set[str], structures: Path) -> dict[str, Path]:
    """Pick the most complete prior domain run whose PDB bytes match exactly."""

    candidates: dict[str, list[tuple[int, Path]]] = {}
    for bundle in (repo / "benchmark_runs").glob("**/evidence/blind_evidence_bundle.json"):
        run_root = bundle.parent.parent
        target = run_root.name
        if target not in target_ids:
            continue
        old_structure = run_root / "input/structure.pdb"
        new_structure = structures / f"{target}.pdb"
        if not old_structure.is_file() or sha256_file(old_structure) != sha256_file(new_structure):
            continue
        count = len(list((run_root / "raw/merizo").glob("*.dom_pdb")))
        count += len(list((run_root / "raw/chainsaw").glob("*_dom.pdb")))
        candidates.setdefault(target, []).append((count, run_root))
    return {
        target: max(items, key=lambda item: (item[0], str(item[1])))[1]
        for target, items in candidates.items()
        if max(items, key=lambda item: item[0])[0] > 0
    }


def reusable_domains(run_root: Path) -> list[tuple[str, int, Path]]:
    output: list[tuple[str, int, Path]] = []
    merizo_table = run_root / "raw/merizo/query_merizo_v2.domains"
    for item in parse_domain_file(merizo_table, "merizo", run_root, cutoff=0.4):
        path = Path(item["_absolute_path"])
        if item["retained"] and path.is_file():
            output.append(("merizo", int(item["domain_index"]), path))

    chainsaw_table = run_root / "raw/chainsaw/query.tsv"
    if chainsaw_table.is_file():
        with chainsaw_table.open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle, delimiter="\t"))
        for row in rows:
            chopping = str(row.get("chopping") or "").strip()
            try:
                confidence = float(row.get("confidence") or 0.0)
            except ValueError:
                confidence = 0.0
            if not chopping or chopping.upper() == "NULL" or confidence < 0.4:
                continue
            for index, _ in enumerate(chopping.split(","), 1):
                path = chainsaw_table.parent / f"query_chainsaw_{index:02d}_dom.pdb"
                if path.is_file():
                    output.append(("chainsaw", index, path))
    return output


def prepare_target_domains(
    target: str,
    structure: Path,
    segment_root: Path,
    external_root: Path | None,
    threads: int,
) -> dict[str, Any]:
    target_root = segment_root / target
    complete = target_root / "complete.json"
    if complete.is_file():
        document = json.loads(complete.read_text(encoding="utf-8"))
        execution = document.get("execution", {})
        disabled_optional = all(
            isinstance(execution.get(method), dict)
            and execution[method].get("reason") == "optional segmenter is not installed"
            for method in ("merizo", "chainsaw")
        )
        if not disabled_optional:
            for item in document["domains"]:
                path = target_root / item["name"]
                if not path.is_file() or sha256_file(path) != item["sha256"]:
                    raise BaselineError(f"cached domain bytes changed: {path}")
            return document

    target_root.mkdir(parents=True, exist_ok=True)
    domains: list[tuple[str, int, Path]] = []
    source = "computed"
    execution: dict[str, Any] = {}
    if external_root is not None:
        domains = reusable_domains(external_root)
        source = "exact-structure prior-run reuse"
        execution = {"sourceRunRoot": str(external_root)}
    if not domains:
        raw = target_root / "raw"
        parsed, execution = run_segmenters(
            structure,
            raw,
            target_root,
            "A",
            threads,
            cutoff=0.4,
        )
        domains = [
            (str(item["method"]), int(item["domain_index"]), Path(item["_absolute_path"]))
            for item in parsed
            if item["retained"] and Path(item["_absolute_path"]).is_file()
        ]

    records: list[dict[str, Any]] = []
    for method, index, source_path in sorted(domains, key=lambda item: (item[0], item[1])):
        destination = target_root / f"{target}__{method}__{index:02d}.pdb"
        shutil.copy2(source_path, destination)
        records.append({
            "name": destination.name,
            "method": method,
            "index": index,
            "sha256": sha256_file(destination),
        })
    document = with_hash({
        "schemaVersion": "pi-z86-groups123-domain-preparation.v1",
        "target": target,
        "structureSha256": sha256_file(structure),
        "source": source,
        "domains": records,
        "execution": execution,
    })
    write_json(complete, document)
    return document


def foldseek_predictions(
    hits: list[dict[str, Any]],
    annotation_store: Path,
    ontology: Ontology,
    output: Path,
    allowed: set[str],
    include_domains: bool,
) -> dict[str, Any]:
    selected: list[tuple[str, str, float, str]] = []
    for hit in hits:
        scope = str(hit.get("scope") or "")
        if not include_domains and scope != "full_length":
            continue
        query = Path(str(hit.get("query_name") or "")).stem
        target = query.split("__", 1)[0]
        donor = hit.get("annotation_accession")
        if target not in allowed or not isinstance(donor, str) or not donor:
            continue
        score = float(hit.get("alignment_tm_score") or 0.0) * float(hit.get("query_coverage") or 0.0)
        score = min(1.0, max(0.0, score))
        if score > 0:
            selected.append((target, donor, score, scope))
    donor_terms = load_direct_terms(annotation_store, (item[1] for item in selected), ontology)
    scores: dict[tuple[str, str], float] = {}
    queries: set[str] = set()
    for target, donor, score, _ in selected:
        terms = donor_terms.get(donor, ())
        if terms:
            queries.add(target)
        for go_id in terms:
            key = (target, go_id)
            scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": "coverage-weighted Foldseek PDB100 250101 T0-GO transfer",
        "configuration": "full_plus_merizo_chainsaw_domains" if include_domains else "full_length_only",
        "termScore": "max(alignment_tm_score * query_coverage)",
        "mappedHitCount": len(selected),
        "queriesWithAnnotatedHits": len(queries),
        "predictionRows": len(scores),
    }


def prepare_foldseek(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    audit = Path(args.audit).resolve()
    output = Path(args.output).resolve()
    targets, target_ids = validate_targets(audit)
    del targets
    if output.exists() and (output / "foldseek_freeze.json").is_file():
        raise BaselineError(f"Foldseek output is already frozen: {output}")
    output.mkdir(parents=True, exist_ok=True)
    structures = audit / "structures_all216"
    segment_root = output / "segments"
    segment_root.mkdir(parents=True, exist_ok=True)
    reusable = external_domain_roots(repo, set(target_ids), structures)

    env = parse_env_file(Path(args.temporal_env).resolve())
    for key in (
        "PYTHON_BIN", "MERIZO_ROOT", "MERIZO_PYTHON", "CHAINSAW_ROOT", "CHAINSAW_PYTHON",
        "FOLDSEEK_BIN", "FOLDSEEK_PDB_DB", "BLASTP_BIN", "BLAST_DB",
    ):
        if not env.get(key):
            raise BaselineError(f"temporal environment lacks {key}")
        os.environ[key] = env[key]

    started = time.monotonic()
    documents: dict[str, Any] = {}
    with ThreadPoolExecutor(max_workers=args.segment_workers) as executor:
        futures = {
            executor.submit(
                prepare_target_domains,
                target,
                structures / f"{target}.pdb",
                segment_root,
                reusable.get(target),
                args.segment_threads,
            ): target
            for target in target_ids
        }
        for completed, future in enumerate(as_completed(futures), 1):
            target = futures[future]
            documents[target] = future.result()
            print(f"domains {completed}/{len(target_ids)} {target}", flush=True)

    full_paths = [structures / f"{target}.pdb" for target in target_ids]
    domain_paths = sorted(
        path
        for target in target_ids
        for path in (segment_root / target).glob(f"{target}__*.pdb")
    )
    search_root = output / "search"
    full_hits, full_record = run_foldseek_scope(
        query_paths=full_paths,
        database="pdb",
        scope="full_length",
        raw_dir=search_root,
        domain_range_by_query={},
        threads=args.search_threads,
        top_k=50,
    )
    domain_hits, domain_record = run_foldseek_scope(
        query_paths=domain_paths,
        database="pdb",
        scope="multiscale_domains",
        raw_dir=search_root,
        domain_range_by_query={},
        threads=args.search_threads,
        top_k=50,
    )
    hits = [*full_hits, *domain_hits]
    bridge = map_pdb_hits_to_t0_uniprot(hits, search_root, args.search_threads, None)
    ontology = Ontology(Path(args.ontology).resolve())
    t0_root = Path(args.t0_root).resolve()
    annotation_store = Path(args.annotation_store).resolve()
    implementations: dict[str, Any] = {}
    for name, include_domains in (("foldseek_full", False), ("foldseek_multiscale", True)):
        implementations[name] = foldseek_predictions(
            hits,
            annotation_store,
            ontology,
            output / name / "predictions.tsv",
            set(target_ids),
            include_domains,
        )
    freeze = with_hash({
        "schemaVersion": "pi-registered-baseline-foldseek-freeze.v1",
        "cohort": args.cohort_id,
        "targetCount": len(target_ids),
        "runnerSha256": sha256_file(Path(__file__).resolve()),
        "structureReceiptSha256": sha256_file(audit / "structure_receipt_all216.json"),
        "pdb100VersionSha256": sha256_file(Path(args.pdb100_version).resolve()),
        "pdb100Database": binary_binding(env["FOLDSEEK_PDB_DB"]),
        "reusedSegmentationTargetCount": sum(item["source"].startswith("exact") for item in documents.values()),
        "computedSegmentationTargetCount": sum(item["source"] == "computed" for item in documents.values()),
        "retainedDomainCount": len(domain_paths),
        "searches": {"full": full_record, "domains": domain_record, "pdbToT0Bridge": bridge},
        "methods": {
            name: {
                "prediction": prediction_stats(output / name / "predictions.tsv"),
                "implementation": implementations[name],
            }
            for name in ("foldseek_full", "foldseek_multiscale")
        },
        "durationSeconds": round(time.monotonic() - started, 3),
        "claimBoundary": (
            "Structure coordinates are anonymous SimpleFold target-only companions. PDB100 is the "
            "frozen 250101 archive; label transfer is admitted only after a sequence bridge to the frozen T0 donor database."
        ),
    })
    write_json(output / "foldseek_freeze.json", freeze)
    print(json.dumps({
        "ok": True,
        "stage": "prepare-foldseek",
        "targetCount": len(target_ids),
        "domainCount": len(domain_paths),
        "freezeHash": freeze["canonicalHash"],
        "durationSeconds": freeze["durationSeconds"],
    }, indent=2))
    return 0


def normalize_deepgoplus(raw_path: Path, output: Path, ontology: Ontology) -> dict[str, Any]:
    scores: dict[tuple[str, str], float] = {}
    with raw_path.open(encoding="utf-8") as handle:
        for raw in handle:
            row = raw.rstrip("\n").split("\t")
            if not row or not row[0]:
                continue
            target = row[0]
            for token in row[1:]:
                go_text, score_text = token.rsplit("|", 1)
                go_id = ontology.canonical(go_text)
                if go_id is None:
                    continue
                score = float(score_text)
                key = (target, go_id)
                scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(scores.items())),
    )
    return {"rawRows": sum(1 for _ in raw_path.open(encoding="utf-8")), "predictionRows": len(scores)}


def run_deepgoplus(
    executable: Path,
    data_root: Path,
    fasta: Path,
    ontology: Ontology,
    output: Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    work = output.parent / "work"
    work.mkdir(parents=True, exist_ok=True)
    raw = work / "raw_predictions.tsv"
    diamond = work / "diamond.res"
    command = [
        str(executable),
        "--data-root", str(data_root),
        "--in-file", str(fasta),
        "--out-file", str(raw),
        "--diamond-file", str(diamond),
        "--threshold", "0.01",
        "--batch-size", "32",
        "--chunk-size", "1000",
    ]
    environment = dict(os.environ)
    environment["PATH"] = str(executable.parent) + os.pathsep + environment.get("PATH", "")
    started_at = time.time()
    started = time.monotonic()
    result = subprocess.run(command, capture_output=True, check=False, timeout=7200, env=environment)
    if result.returncode != 0:
        raise BaselineError(
            f"DeepGOPlus failed ({result.returncode}): "
            + result.stderr.decode("utf-8", errors="replace")[-4000:]
        )
    execution = {
        "command": command,
        "startedAtUnix": started_at,
        "durationSeconds": round(time.monotonic() - started, 3),
        "returncode": result.returncode,
        "stdoutTail": result.stdout.decode("utf-8", errors="replace")[-2000:],
        "stderrTail": result.stderr.decode("utf-8", errors="replace")[-2000:],
    }
    return {
        "algorithm": "stock DeepGOPlus hybrid CNN + DIAMOND with release metadata aspect alphas",
        "binary": binary_binding(str(executable)),
        "dataRoot": str(data_root),
        "dataFiles": {
            name: sha256_file(data_root / name)
            for name in ("model.h5", "terms.pkl", "go.obo", "train_data.pkl", "train_data.dmnd")
        },
        **normalize_deepgoplus(raw, output, ontology),
    }, [execution]


def run_mdeepfri_portable(
    repo: Path,
    architecture: str,
    targets: dict[str, str],
    structures: Path,
    ontology: Ontology,
    output: Path,
    python_bin: Path,
    threshold: float = 0.01,
) -> dict[str, Any]:
    work = output.parent / "work"
    work.mkdir(parents=True, exist_ok=True)
    method, artifacts, runner, _, source_config_sha256 = deepfri_method(
        repo, architecture, threshold, work / "adapter_config.json"
    )
    reverse: dict[str, list[str]] = {}
    cases: list[dict[str, Any]] = []
    binding_to_case: dict[tuple[str, str], str] = {}
    unsupported_target_count = 0
    for index, (target, sequence) in enumerate(targets.items(), start=1):
        # The hash-locked GCN adapter has a 2,500-residue fail-closed contract.
        # Longer Benchmark targets remain unpredicted rather than being truncated.
        if architecture == "gcn" and (len(sequence) > 2500 or any(residue not in "ACDEFGHIKLMNPQRSTVWY" for residue in sequence)):
            unsupported_target_count += 1
            continue
        fasta_hash = canonical_fasta_hash(sequence)
        structure = structures / f"{target}.pdb" if architecture == "gcn" else None
        structure_hash = sha256_file(structure) if structure is not None else ""
        # The adapters require unique sequence bindings per request. Exact
        # duplicate target sequences share the first deterministic structure
        # and prediction; the result is copied back to every bound target.
        binding = (fasta_hash, "")
        prior = binding_to_case.get(binding)
        if prior is not None:
            reverse[prior].append(target)
            continue
        # Adapter case IDs use a three-digit slot. Include a target-bound hash
        # so slots can be reused safely across requests larger than 999 cases.
        opaque_hash = hashlib.sha256((target + "\0" + sequence + "\0" + structure_hash).encode("utf-8")).hexdigest()
        case_id = f"CASE_{((len(cases)) % 999) + 1:03d}_{opaque_hash[:8].upper()}"
        binding_to_case[binding] = case_id
        reverse[case_id] = [target]
        case: dict[str, Any] = {"caseId": case_id, "sequenceSha256": fasta_hash, "sequence": sequence}
        if structure is not None:
            case.update({"structureSha256": structure_hash, "structurePath": str(structure)})
        cases.append(case)
    started = time.monotonic()
    max_batch_residues = 90_000 if architecture == "gcn" else 1_900_000
    case_batches: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    current_residues = 0
    for case in cases:
        residues = len(str(case["sequence"]))
        # The fail-closed adapters accept at most 1,000 cases per request in
        # addition to the architecture-specific residue budget.
        if current and (len(current) >= 999 or current_residues + residues > max_batch_residues):
            case_batches.append(current)
            current = []
            current_residues = 0
        current.append(case)
        current_residues += residues
    if current:
        case_batches.append(current)

    responses: list[dict[str, Any]] = []
    batch_records: list[dict[str, Any]] = []
    for batch_index, batch in enumerate(case_batches, start=1):
        request = {
            "schemaVersion": "pi-external-go-predictor-run-request.v1" if architecture == "cnn" else "pi-external-go-gcn-run-request.v1",
            "method": method,
            "artifacts": artifacts,
            "cases": batch,
        }
        request_path = work / f"request_{batch_index:03d}.json"
        response_path = work / f"response_{batch_index:03d}.json"
        request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        batch_started = time.monotonic()
        result = subprocess.run(
            [str(python_bin), str(runner)],
            input=request_path.read_bytes(),
            capture_output=True,
            timeout=7200,
            check=False,
        )
        if result.returncode != 0:
            raise BaselineError(
                f"mDeepFRI {architecture} batch {batch_index}/{len(case_batches)} failed "
                f"({result.returncode}): "
                + result.stderr.decode("utf-8", errors="replace")[-4000:]
            )
        response_path.write_bytes(result.stdout)
        response = json.loads(result.stdout)
        responses.extend(response["cases"])
        batch_records.append({
            "batch": batch_index,
            "caseCount": len(batch),
            "residueCount": sum(len(str(case["sequence"])) for case in batch),
            "requestSha256": sha256_file(request_path),
            "responseSha256": sha256_file(response_path),
            "durationSeconds": round(time.monotonic() - batch_started, 3),
        })
    scores: dict[tuple[str, str], float] = {}
    for item in responses:
        bound_targets = reverse[item["caseId"]]
        for prediction in item["predictions"]:
            go_id = ontology.canonical(prediction["goId"])
            if go_id is None or go_id == ROOTS[ontology.namespace[go_id]]:
                continue
            score = float(prediction["score"])
            for target in bound_targets:
                key = (target, go_id)
                scores[key] = max(scores.get(key, 0.0), score)
    write_predictions(
        output,
        ((target, go_id, score) for (target, go_id), score in sorted(scores.items())),
    )
    return {
        "algorithm": f"hash-bound mDeepFRI {architecture.upper()} fixed checkpoint",
        "architecture": architecture,
        "python": binary_binding(str(python_bin)),
        "method": method,
        "upstreamSourceConfigSha256": source_config_sha256,
        "batches": batch_records,
        "durationSeconds": round(time.monotonic() - started, 3),
        "predictionRows": len(scores),
        "unsupportedTargetCount": unsupported_target_count,
        "unsupportedPolicy": "GCN targets longer than 2,500 residues or containing non-standard residues emit no rows; sequences are never truncated or rewritten.",
        "uniqueInputBindingCount": len(cases),
        "exactDuplicateTargetCount": len(targets) - unsupported_target_count - len(cases),
        "exactDuplicatePolicy": "Exact duplicate sequences share the first target-ordered input binding and prediction.",
        "checkpointClaimBoundary": "Pre-T0 checkpoint; exact sequence-level training overlap was not audited.",
    }


def predict(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    audit = Path(args.audit).resolve()
    t0_root = Path(args.t0_root).resolve()
    foldseek_root = Path(args.foldseek).resolve()
    output = Path(args.output).resolve()
    if output.exists() and any(output.iterdir()):
        raise BaselineError(f"prediction output already exists: {output}")
    output.mkdir(parents=True, exist_ok=True)
    targets, target_ids = validate_targets(audit)
    target_set = set(target_ids)
    ontology = Ontology(Path(args.ontology).resolve())
    annotation_store = Path(args.annotation_store).resolve()
    t0 = t0_root
    receipts: dict[str, Any] = {}

    def finish(
        name: str,
        implementation: dict[str, Any],
        executions: list[dict[str, Any]] | None = None,
        eligibility: str = "formal_t0",
    ) -> None:
        receipts[name] = method_receipt(
            output / name / "predictions.tsv",
            name,
            implementation,
            executions or [],
            eligibility,
        )
        print(f"finished {name}", flush=True)

    finish("lafa_naive", naive_predictions(
        target_ids, t0 / "train_terms_propagated.tsv", ontology, output / "lafa_naive/predictions.tsv"
    ))

    implementation, executions = run_deepgoplus(
        Path(args.deepgoplus),
        Path(args.deepgoplus_data).resolve(),
        audit / "targets.fasta",
        ontology,
        output / "deepgoplus_1_0_2_data_1_0_25/predictions.tsv",
    )
    finish(
        "deepgoplus_1_0_2_data_1_0_25",
        implementation,
        executions,
        eligibility="fixed_checkpoint_temporal_not_training_clean",
    )

    searches: list[tuple[str, list[str], Path, str]] = []
    blast_hits = output / "blastp_identity/work/hits.tsv"
    blast_hits.parent.mkdir(parents=True, exist_ok=True)
    searches.append((
        "blastp_identity",
        [
            args.blastp, "-query", str(audit / "targets.fasta"), "-db",
            str(Path(args.blast_db).resolve()), "-out", str(blast_hits),
            "-outfmt", "6 qseqid sseqid evalue length pident nident qlen slen bitscore",
            "-evalue", "10", "-max_target_seqs", "500", "-num_threads", str(args.threads),
        ],
        blast_hits,
        "identity",
    ))

    diamond_work = output / "diamond_identity/work"
    diamond_work.mkdir(parents=True, exist_ok=True)
    diamond_db = diamond_work / "lafa_sep2025"
    diamond_make = run_command([
        args.diamond, "makedb", "--in", str(t0 / "train_sequences.fasta"), "--db", str(diamond_db)
    ], cwd=repo, timeout=1800)
    diamond_hits = diamond_work / "hits.tsv"
    diamond_command = [
        args.diamond, "blastp", "--query", str(audit / "targets.fasta"), "--db", str(diamond_db),
        "--out", str(diamond_hits), "--outfmt", "6", "qseqid", "sseqid", "evalue", "length",
        "pident", "nident", "qlen", "slen", "bitscore", "--evalue", "10",
        "--max-target-seqs", "500", "--threads", str(args.threads),
    ]
    diamond_execution = run_command(diamond_command, cwd=repo, timeout=3600)
    diamond_common = {
        "binary": binary_binding(args.diamond),
        "databaseSha256": sha256_file(Path(str(diamond_db) + ".dmnd")),
        "searchDatabase": "LAFA Sep-2025 T0 donors",
    }
    for name, mode in (("diamond_identity", "identity"), ("diamond_score", "diamond_score")):
        finish(name, {
            **diamond_common,
            **tabular_transfer(
                diamond_hits, annotation_store, ontology, output / name / "predictions.tsv", score_mode=mode
            ),
            "configurationBoundary": "same DIAMOND search; score aggregation differs",
        }, [diamond_make, diamond_execution])

    mmseqs_hits = output / "mmseqs2_identity/work/hits.tsv"
    mmseqs_hits.parent.mkdir(parents=True, exist_ok=True)
    searches.append((
        "mmseqs2_identity",
        [
            args.mmseqs, "easy-search", str(audit / "targets.fasta"), str(t0 / "train_sequences.fasta"),
            str(mmseqs_hits), str(mmseqs_hits.parent / "tmp"), "--format-output",
            "query,target,evalue,alnlen,pident,nident,qlen,tlen,bits", "--max-seqs", "500",
            "--threads", str(args.threads),
        ],
        mmseqs_hits,
        "identity",
    ))
    for name, command, hit_path, mode in searches:
        execution = run_command(command, cwd=repo, timeout=3600)
        finish(name, {
            "binary": binary_binding(command[0]),
            "searchDatabase": "LAFA Sep-2025 T0 donors",
            **tabular_transfer(
                hit_path, annotation_store, ontology, output / name / "predictions.tsv", score_mode=mode
            ),
        }, [execution])

    phmmer_table = output / "phmmer_score/work/hits.tbl"
    phmmer_table.parent.mkdir(parents=True, exist_ok=True)
    phmmer_execution = run_command([
        args.phmmer, "--tblout", str(phmmer_table), "--noali", "--cpu", str(args.threads),
        "-E", "10", str(audit / "targets.fasta"), str(t0 / "train_sequences.fasta"),
    ], cwd=repo, timeout=7200)
    finish("phmmer_score", {
        "binary": binary_binding(args.phmmer),
        "searchDatabase": "LAFA Sep-2025 T0 donors",
        **phmmer_transfer(phmmer_table, annotation_store, ontology, output / "phmmer_score/predictions.tsv"),
    }, [phmmer_execution])

    foldseek_freeze = json.loads((foldseek_root / "foldseek_freeze.json").read_text(encoding="utf-8"))
    expected_foldseek_hash = foldseek_freeze.pop("canonicalHash")
    if canonical_hash(foldseek_freeze) != expected_foldseek_hash:
        raise BaselineError("Foldseek freeze canonical hash mismatch")
    for name in ("foldseek_full", "foldseek_multiscale"):
        source = foldseek_root / name / "predictions.tsv"
        expected = foldseek_freeze["methods"][name]["prediction"]["sha256"]
        if sha256_file(source) != expected:
            raise BaselineError(f"Foldseek prediction changed after freeze: {name}")
        finish(name, copy_frozen_predictions(source, output / name / "predictions.tsv", target_set))

    for name, architecture, python_bin in (
        ("mdeepfri_cnn", "cnn", Path(args.mdeepfri_cnn_python)),
        ("mdeepfri_gcn", "gcn", Path(args.mdeepfri_gcn_python)),
    ):
        finish(name, run_mdeepfri_portable(
            repo,
            architecture,
            targets,
            audit / "structures_all216",
            ontology,
            output / name / "predictions.tsv",
            python_bin.absolute(),
        ), eligibility="fixed_checkpoint_temporal_not_training_clean")

    fusion_inputs = {
        item: output / item / "predictions.tsv"
        for item in (
            "deepgoplus_1_0_2_data_1_0_25",
            "blastp_identity",
            "phmmer_score",
            "foldseek_multiscale",
        )
    }
    finish(
        "fixed_fusion_max",
        fixed_max_fusion(fusion_inputs, target_set, output / "fixed_fusion_max/predictions.tsv"),
        eligibility="fixed_checkpoint_plus_formal_t0_static_control",
    )

    if set(receipts) != set(METHODS):
        raise BaselineError("method set differs from the declared 12 non-agent baselines")
    freeze = with_hash({
        "schemaVersion": "pi-registered-baseline-prediction-freeze.v1",
        "cohort": args.cohort_id,
        "targetCount": len(target_ids),
        "runnerSha256": sha256_file(Path(__file__).resolve()),
        "resourceBindings": {
            "publicOntologySha256": sha256_file(Path(args.ontology).resolve()),
            "t0TrainSequencesSha256": sha256_file(t0 / "train_sequences.fasta"),
            "t0PropagatedTermsSha256": sha256_file(t0 / "train_terms_propagated.tsv"),
            "t0CoreManifestSha256": sha256_file(t0_root / "manifest.json"),
            "t0DirectTermsSha256": sha256_file(t0_root / "train_terms.tsv"),
            "structureReceiptSha256": sha256_file(audit / "structure_receipt_all216.json"),
            "foldseekFreezeHash": expected_foldseek_hash,
        },
        "targetIdsSha256": sha256_file(audit / "target_ids.txt"),
        "targetFastaSha256": sha256_file(audit / "targets.fasta"),
        "methods": {
            name: {
                "predictionSha256": receipt["prediction"]["sha256"],
                "predictionRows": receipt["prediction"]["rowCount"],
                "predictedTargetCount": receipt["prediction"]["predictedTargetCount"],
                "receiptHash": receipt["canonicalHash"],
                "eligibility": receipt["eligibility"],
            }
            for name, receipt in sorted(receipts.items())
        },
        "claimBoundary": (
            "All 216-target prediction bytes were frozen before any evaluator-private path was accepted. "
            "Groups are topology-selected sensitivity cohorts; fixed checkpoints are not all training-clean."
        ),
    })
    write_json(output / "prediction_freeze.json", freeze)
    print(json.dumps({
        "ok": True,
        "stage": "predict",
        "methodCount": len(receipts),
        "freezeHash": freeze["canonicalHash"],
        "output": str(output),
    }, indent=2))
    return 0


def group_directories(root: Path) -> list[tuple[str, Path]]:
    output: list[tuple[str, Path]] = []
    for index in (1, 2, 3):
        choices = sorted(path for path in root.glob(f"group_{index}_*") if path.is_dir())
        if len(choices) != 1:
            raise BaselineError(f"expected one group {index} benchmark, found {len(choices)}")
        output.append((f"group_{index}", choices[0]))
    return output


def write_table(group: str, metrics: dict[str, Any], output: Path) -> None:
    labels = [
        "method",
        "Overall Fmax", "Overall AUPR", "Overall IA-wFmax", "Overall nSmin",
        "MF Fmax", "MF AUPR", "MF IA-wFmax", "MF Smin",
        "BP Fmax", "BP AUPR", "BP IA-wFmax", "BP Smin",
        "CC Fmax", "CC AUPR", "CC IA-wFmax", "CC Smin",
    ]
    lines = ["\t".join(labels) + "\n"]
    for method in METHODS:
        values = [DISPLAY_NAMES[method]]
        values.extend(f"{metrics[method][scope][metric]:.6f}" for scope, metric in TABLE_METRICS)
        lines.append("\t".join(values) + "\n")
    output.write_text("".join(lines), encoding="utf-8")

    md = [
        f"## {group.replace('_', ' ').title()} (n=72)\n\n",
        "| Method | Overall Fmax | Overall AUPR | Overall IA-wFmax | Overall nSmin | MF Fmax | MF AUPR | MF IA-wFmax | MF Smin | BP Fmax | BP AUPR | BP IA-wFmax | BP Smin | CC Fmax | CC AUPR | CC IA-wFmax | CC Smin |\n",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n",
    ]
    for method in METHODS:
        values = [DISPLAY_NAMES[method]]
        values.extend(f"{metrics[method][scope][metric]:.4f}" for scope, metric in TABLE_METRICS)
        md.append("| " + " | ".join(values) + " |\n")
    output.with_suffix(".md").write_text("".join(md), encoding="utf-8")


def evaluate(args: argparse.Namespace) -> int:
    repo = Path(args.repo).resolve()
    audit = Path(args.audit).resolve()
    prediction_root = Path(args.predictions).resolve()
    benchmark_root = Path(args.benchmark_root).resolve()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    freeze_document = json.loads((prediction_root / "prediction_freeze.json").read_text(encoding="utf-8"))
    expected_hash = freeze_document.pop("canonicalHash")
    if canonical_hash(freeze_document) != expected_hash:
        raise BaselineError("prediction freeze canonical hash mismatch")
    if sha256_file(Path(__file__).resolve()) != freeze_document["runnerSha256"]:
        raise BaselineError("runner changed after prediction freeze")
    if tuple(sorted(freeze_document["methods"])) != tuple(sorted(METHODS)):
        raise BaselineError("prediction freeze method set is not the declared 12")

    summaries: dict[str, Any] = {}
    markdown_parts = [
        "# Z-86 Groups 1--3: non-agent baseline benchmark\n\n",
        "All predictions were generated once on the 216-target union, hash-frozen before evaluation, and scored on three disjoint 72-target masks. Overall reports nSmin; MF/BP/CC report Smin. Higher is better except nSmin/Smin.\n\n",
    ]
    for group, benchmark in group_directories(benchmark_root):
        group_root = output / group
        group_root.mkdir(parents=True, exist_ok=True)
        target_ids = list(read_fasta(benchmark / "public/targets.fasta"))
        if len(target_ids) != 72 or len(set(target_ids)) != 72:
            raise BaselineError(f"{group} is not exact 72")
        target_ids_path = group_root / "target_ids.txt"
        target_ids_path.write_text("\n".join(target_ids) + "\n", encoding="utf-8")
        metrics: dict[str, Any] = {}
        executions: dict[str, Any] = {}
        subset_hashes: dict[str, str] = {}
        for method in METHODS:
            source = prediction_root / method / "predictions.tsv"
            expected = freeze_document["methods"][method]["predictionSha256"]
            if sha256_file(source) != expected:
                raise BaselineError(f"prediction changed after freeze: {method}")
            prediction = group_root / method / "predictions.tsv"
            copy_frozen_predictions(source, prediction, set(target_ids))
            subset_hashes[method] = sha256_file(prediction)
            report = group_root / method / "metrics.json"
            execution = run_command([
                sys.executable,
                str(repo / "scripts/evaluate_lafa_temporal_benchmark.py"),
                "--benchmark", str(benchmark),
                "--predictions", str(prediction),
                "--target-ids", str(target_ids_path),
                "--output", str(report),
            ], cwd=repo, timeout=3600)
            executions[method] = execution
            metrics[method] = compact_metrics(json.loads(report.read_text(encoding="utf-8")))
        write_table(group, metrics, group_root / "metrics_16.tsv")
        markdown_parts.append((group_root / "metrics_16.md").read_text(encoding="utf-8") + "\n")
        protocol = json.loads((benchmark / "evaluation/protocol.json").read_text(encoding="utf-8"))
        summaries[group] = {
            "benchmark": str(benchmark),
            "suiteId": protocol["suiteId"],
            "protocolCanonicalHash": protocol["canonicalHash"],
            "targetCount": len(target_ids),
            "targetIdsSha256": sha256_file(target_ids_path),
            "subsetPredictionHashes": subset_hashes,
            "metrics": metrics,
            "executions": executions,
        }
    (output / "baseline_tables_3groups.md").write_text("".join(markdown_parts), encoding="utf-8")
    summary = with_hash({
        "schemaVersion": "pi-z86-groups123-baseline-summary.v1",
        "predictionFreezeHash": expected_hash,
        "methodCount": len(METHODS),
        "groupCount": 3,
        "groups": summaries,
        "tableMetricContract": [f"{scope}:{metric}" for scope, metric in TABLE_METRICS],
        "claimBoundary": (
            "Paired within each topology-selected sensitivity group. Group 1 is DeepGOPlus data-1.0.25 "
            "exact-sequence clean; groups 2 and 3 overlap that training release. Search variants and the fixed "
            "fusion are configurations, not independent learned models. No agent row was run."
        ),
    })
    write_json(output / "metrics_summary.json", summary)
    print(json.dumps({
        "ok": True,
        "stage": "evaluate",
        "methodCount": len(METHODS),
        "groupCount": 3,
        "summaryHash": summary["canonicalHash"],
        "markdown": str(output / "baseline_tables_3groups.md"),
    }, indent=2))
    return 0


def parser() -> argparse.ArgumentParser:
    repo = SUITE_ROOT
    run_root = repo / ".local/fixed12"
    t0_root = repo / "resources/t0"
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--cohort-id", default="registered-query-cohort")
    stages = value.add_subparsers(dest="stage", required=True)

    foldseek = stages.add_parser("prepare-foldseek")
    foldseek.add_argument("--repo", default=str(repo))
    foldseek.add_argument("--audit", default=str(run_root / "audit"))
    foldseek.add_argument("--output", default=str(run_root / "foldseek"))
    foldseek.add_argument("--ontology", required=True)
    foldseek.add_argument("--t0-root", default=str(t0_root))
    foldseek.add_argument("--annotation-store", default=str(repo / ".local/reference/t0_annotations.sqlite3"))
    foldseek.add_argument(
        "--temporal-env",
        required=True,
    )
    foldseek.add_argument(
        "--pdb100-version",
        required=True,
    )
    foldseek.add_argument("--segment-workers", type=int, choices=range(1, 9), default=4)
    foldseek.add_argument("--segment-threads", type=int, choices=range(1, 17), default=4)
    foldseek.add_argument("--search-threads", type=int, choices=range(1, 17), default=8)

    predict_parser = stages.add_parser("predict")
    predict_parser.add_argument("--repo", default=str(repo))
    predict_parser.add_argument("--audit", default=str(run_root / "audit"))
    predict_parser.add_argument("--output", default=str(run_root / "predictions"))
    predict_parser.add_argument("--foldseek", default=str(run_root / "foldseek"))
    predict_parser.add_argument("--ontology", required=True)
    predict_parser.add_argument("--t0-root", default=str(t0_root))
    predict_parser.add_argument("--annotation-store", default=str(repo / ".local/reference/t0_annotations.sqlite3"))
    predict_parser.add_argument("--blast-db", default=str(repo / ".local/reference/blast/lafa_sep2025"))
    predict_parser.add_argument("--threads", type=int, choices=range(1, 17), default=4)
    predict_parser.add_argument("--blastp", default=str(repo / ".runtime/env/bin/blastp"))
    predict_parser.add_argument("--diamond", required=True)
    predict_parser.add_argument("--mmseqs", default=shutil.which("mmseqs") or "mmseqs")
    predict_parser.add_argument(
        "--phmmer", default=str(repo / ".runtime/predictors/hmmer-baseline-v1/bin/phmmer")
    )
    predict_parser.add_argument(
        "--deepgoplus", required=True
    )
    predict_parser.add_argument(
        "--deepgoplus-data", required=True
    )
    predict_parser.add_argument(
        "--mdeepfri-cnn-python",
        default=str(repo / ".runtime/disabled-optional-20260805/predictors/mdeepfri-cnn-v1/bin/python"),
    )
    predict_parser.add_argument(
        "--mdeepfri-gcn-python",
        default=str(repo / ".runtime/disabled-optional-20260805/predictors/mdeepfri-gcn-v1/bin/python"),
    )

    evaluate_parser = stages.add_parser("evaluate")
    evaluate_parser.add_argument("--repo", default=str(repo))
    evaluate_parser.add_argument("--audit", default=str(run_root / "audit"))
    evaluate_parser.add_argument("--predictions", default=str(run_root / "predictions"))
    evaluate_parser.add_argument("--output", default=str(run_root / "evaluation"))
    evaluate_parser.add_argument("--benchmark-root", required=True)
    return value


if __name__ == "__main__":
    arguments = parser().parse_args()
    if arguments.stage == "prepare-foldseek":
        raise SystemExit(prepare_foldseek(arguments))
    if arguments.stage == "predict":
        raise SystemExit(predict(arguments))
    raise SystemExit(evaluate(arguments))
